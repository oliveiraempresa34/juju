import React, { useMemo } from "react";
import { GameScene } from "../game/GameScene";
import { useRoomStore } from "../store/useRoom";
import { useAppStore } from "../store/useApp";
import { useGameStore } from "../store/useGame";

const GamePage: React.FC = () => {
  const { setScreen } = useAppStore();
  const { gameMode } = useGameStore();
  const { status, players, localPlayerId, seed, error } = useRoomStore((state) => ({
    status: state.status,
    players: state.players,
    localPlayerId: state.localPlayerId,
    seed: state.seed,
    error: state.error
  }));

  const localPlayer = localPlayerId ? players[localPlayerId] : undefined;
  const remoteDrivers = useMemo(
    () =>
      Object.values(players).filter((player) => player.id !== localPlayerId),
    [players, localPlayerId]
  );

  return (
    <div style={{ position: "relative", width: "100vw", height: "100vh", overflow: "hidden" }}>
      <GameScene />

      {/* Mostrador de erro apenas se houver erro */}
      {error && (
        <div
          style={{
            position: "absolute",
            top: 16,
            left: 16,
            background: "rgba(220, 53, 69, 0.9)",
            color: "#fff",
            padding: "8px 12px",
            borderRadius: 6,
            fontSize: 14
          }}
        >
          {error}
        </div>
      )}

      {gameMode === 'multiplayer' && remoteDrivers.length > 0 && (
        <div
          style={{
            position: "absolute",
            top: 16,
            right: 16,
            background: "rgba(0, 0, 0, 0.45)",
            color: "#fff",
            padding: "12px 16px",
            borderRadius: 8,
            maxWidth: 220
          }}
        >
          <div style={{ fontWeight: 600, marginBottom: 6 }}>Ghosts</div>
          {remoteDrivers.map((player) => (
            <div key={player.id} style={{ fontSize: 14, marginBottom: 4 }}>
              {player.name} � {player.distance.toFixed(1)} u
            </div>
          ))}
        </div>
      )}

      <div
        style={{
          position: "absolute",
          bottom: 16,
          left: "50%",
          transform: "translateX(-50%)",
          background: "rgba(0, 0, 0, 0.35)",
          color: "#fff",
          padding: "10px 18px",
          borderRadius: 999,
          fontSize: 14
        }}
      >
        Hold click / tap / space to drift right
      </div>
    </div>
  );
};

export default GamePage;