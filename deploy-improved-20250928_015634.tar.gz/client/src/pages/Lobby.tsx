import React, { useState } from 'react';
import { useAuthStore } from '../store/useAuth';
import { useAppStore } from '../store/useApp';
import { useGameStore } from '../store/useGame';

export const Lobby: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'play' | 'leaderboard' | 'profile'>('play');
  const { user, logout } = useAuthStore();
  const { setScreen } = useAppStore();
  const { setGameMode, resetGame } = useGameStore();

  const handleStartMultiplayerGame = () => {
    resetGame();
    setGameMode('multiplayer');
    setScreen('game');
  };

  const handleStartDemoGame = () => {
    resetGame();
    setGameMode('demo');
    setScreen('game');
  };

  const handleStartPracticeGame = () => {
    resetGame();
    setGameMode('practice');
    setScreen('game');
  };

  const handleLogout = () => {
    logout();
    setScreen('login');
  };

  return (
    <div style={{
      width: '100vw',
      height: '100vh',
      background: 'linear-gradient(135deg, #232526 0%, #414345 100%)',
      fontFamily: 'Arial, sans-serif',
      color: 'white'
    }}>
      {/* Header */}
      <div style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        padding: '20px 40px',
        background: 'rgba(0,0,0,0.3)',
        borderBottom: '1px solid rgba(255,255,255,0.1)'
      }}>
        <div>
          <h1 style={{
            margin: 0,
            fontSize: '24px',
            fontWeight: 'bold'
          }}>
            🏎️ DRIFT TO RIGHT
          </h1>
        </div>

        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '20px'
        }}>
          <div style={{
            background: 'rgba(255,255,255,0.1)',
            padding: '10px 20px',
            borderRadius: '20px',
            fontSize: '14px'
          }}>
            💰 Balance: ${user?.balance?.toFixed(2) || '0.00'}
          </div>

          <div style={{
            background: 'rgba(255,255,255,0.1)',
            padding: '10px 20px',
            borderRadius: '20px',
            fontSize: '14px'
          }}>
            👤 {user?.username}
          </div>

          <button
            onClick={handleLogout}
            style={{
              background: '#dc3545',
              color: 'white',
              border: 'none',
              padding: '10px 20px',
              borderRadius: '20px',
              cursor: 'pointer',
              fontSize: '14px',
              fontWeight: 'bold'
            }}
          >
            Logout
          </button>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div style={{
        display: 'flex',
        padding: '20px 40px',
        gap: '20px'
      }}>
        {(['play', 'leaderboard', 'profile'] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            style={{
              background: activeTab === tab ? '#667eea' : 'rgba(255,255,255,0.1)',
              color: 'white',
              border: 'none',
              padding: '15px 30px',
              borderRadius: '12px',
              cursor: 'pointer',
              fontSize: '16px',
              fontWeight: activeTab === tab ? 'bold' : 'normal',
              textTransform: 'capitalize',
              transition: 'all 0.3s ease'
            }}
          >
            {tab === 'play' && '🎮'}
            {tab === 'leaderboard' && '🏆'}
            {tab === 'profile' && '👤'}
            {' ' + tab}
          </button>
        ))}
      </div>

      {/* Content Area */}
      <div style={{
        padding: '0 40px 40px 40px',
        height: 'calc(100vh - 200px)',
        overflow: 'auto'
      }}>
        {activeTab === 'play' && (
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
            gap: '30px',
            maxWidth: '1200px'
          }}>
            {/* Multiplayer Mode */}
            <div style={{
              background: 'rgba(255,255,255,0.1)',
              padding: '30px',
              borderRadius: '20px',
              textAlign: 'center'
            }}>
              <div style={{ fontSize: '48px', marginBottom: '20px' }}>💰</div>
              <h3 style={{ margin: '0 0 15px 0', fontSize: '24px' }}>Betting Mode</h3>
              <p style={{ margin: '0 0 25px 0', color: '#ccc' }}>
                Play against others with real stakes and prizes
              </p>
              <button
                onClick={handleStartMultiplayerGame}
                style={{
                  background: 'linear-gradient(135deg, #28a745 0%, #20c997 100%)',
                  color: 'white',
                  border: 'none',
                  padding: '15px 40px',
                  borderRadius: '25px',
                  cursor: 'pointer',
                  fontSize: '18px',
                  fontWeight: 'bold',
                  transition: 'transform 0.2s ease'
                }}
                onMouseDown={(e) => e.currentTarget.style.transform = 'scale(0.95)'}
                onMouseUp={(e) => e.currentTarget.style.transform = 'scale(1)'}
                onMouseLeave={(e) => e.currentTarget.style.transform = 'scale(1)'}
              >
                Join Betting Game
              </button>
            </div>

            {/* Demo Mode */}
            <div style={{
              background: 'rgba(255,255,255,0.1)',
              padding: '30px',
              borderRadius: '20px',
              textAlign: 'center'
            }}>
              <div style={{ fontSize: '48px', marginBottom: '20px' }}>🎮</div>
              <h3 style={{ margin: '0 0 15px 0', fontSize: '24px' }}>Demo Mode</h3>
              <p style={{ margin: '0 0 25px 0', color: '#ccc' }}>
                Try the game instantly - no connection required
              </p>
              <button
                onClick={handleStartDemoGame}
                style={{
                  background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                  color: 'white',
                  border: 'none',
                  padding: '15px 40px',
                  borderRadius: '25px',
                  cursor: 'pointer',
                  fontSize: '18px',
                  fontWeight: 'bold',
                  transition: 'transform 0.2s ease'
                }}
                onMouseDown={(e) => e.currentTarget.style.transform = 'scale(0.95)'}
                onMouseUp={(e) => e.currentTarget.style.transform = 'scale(1)'}
                onMouseLeave={(e) => e.currentTarget.style.transform = 'scale(1)'}
              >
                Play Demo
              </button>
            </div>

            {/* Practice Mode */}
            <div style={{
              background: 'rgba(255,255,255,0.1)',
              padding: '30px',
              borderRadius: '20px',
              textAlign: 'center'
            }}>
              <div style={{ fontSize: '48px', marginBottom: '20px' }}>🎯</div>
              <h3 style={{ margin: '0 0 15px 0', fontSize: '24px' }}>Practice Mode</h3>
              <p style={{ margin: '0 0 25px 0', color: '#ccc' }}>
                Hone your drifting skills without betting
              </p>
              <button
                onClick={handleStartPracticeGame}
                style={{
                  background: 'rgba(255,255,255,0.2)',
                  color: 'white',
                  border: '2px solid #667eea',
                  padding: '15px 40px',
                  borderRadius: '25px',
                  cursor: 'pointer',
                  fontSize: '18px',
                  fontWeight: 'bold',
                  transition: 'all 0.2s ease'
                }}
              >
                Practice
              </button>
            </div>

            {/* Tournament */}
            <div style={{
              background: 'rgba(255,255,255,0.1)',
              padding: '30px',
              borderRadius: '20px',
              textAlign: 'center'
            }}>
              <div style={{ fontSize: '48px', marginBottom: '20px' }}>🏆</div>
              <h3 style={{ margin: '0 0 15px 0', fontSize: '24px' }}>Tournament</h3>
              <p style={{ margin: '0 0 25px 0', color: '#ccc' }}>
                Compete in organized tournaments for bigger prizes
              </p>
              <button
                style={{
                  background: '#6c757d',
                  color: 'white',
                  border: 'none',
                  padding: '15px 40px',
                  borderRadius: '25px',
                  cursor: 'not-allowed',
                  fontSize: '18px',
                  fontWeight: 'bold'
                }}
                disabled
              >
                Coming Soon
              </button>
            </div>
          </div>
        )}

        {activeTab === 'leaderboard' && (
          <div style={{
            background: 'rgba(255,255,255,0.1)',
            padding: '30px',
            borderRadius: '20px',
            maxWidth: '800px'
          }}>
            <h2 style={{ margin: '0 0 30px 0', textAlign: 'center' }}>🏆 Global Leaderboard</h2>
            <div style={{
              display: 'grid',
              gridTemplateColumns: '50px 1fr 150px 150px',
              gap: '15px',
              alignItems: 'center',
              fontWeight: 'bold',
              borderBottom: '2px solid rgba(255,255,255,0.2)',
              paddingBottom: '15px',
              marginBottom: '20px'
            }}>
              <div>Rank</div>
              <div>Player</div>
              <div>Best Distance</div>
              <div>Total Wins</div>
            </div>

            {[
              { rank: 1, name: 'DriftKing', distance: '2847.3', wins: 156 },
              { rank: 2, name: 'SpeedDemon', distance: '2734.8', wins: 134 },
              { rank: 3, name: 'RaceAce', distance: '2698.1', wins: 112 },
              { rank: 4, name: user?.username || 'You', distance: '1234.5', wins: 23 },
              { rank: 5, name: 'Novice', distance: '987.2', wins: 8 }
            ].map((player, index) => (
              <div
                key={player.rank}
                style={{
                  display: 'grid',
                  gridTemplateColumns: '50px 1fr 150px 150px',
                  gap: '15px',
                  alignItems: 'center',
                  padding: '15px 0',
                  borderBottom: '1px solid rgba(255,255,255,0.1)',
                  background: player.name === user?.username ? 'rgba(102, 126, 234, 0.2)' : 'transparent'
                }}
              >
                <div style={{ textAlign: 'center', fontWeight: 'bold' }}>
                  {player.rank <= 3 ? ['🥇', '🥈', '🥉'][player.rank - 1] : player.rank}
                </div>
                <div>{player.name}</div>
                <div>{player.distance}m</div>
                <div>{player.wins}</div>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'profile' && (
          <div style={{
            background: 'rgba(255,255,255,0.1)',
            padding: '30px',
            borderRadius: '20px',
            maxWidth: '600px'
          }}>
            <h2 style={{ margin: '0 0 30px 0', textAlign: 'center' }}>👤 Player Profile</h2>

            <div style={{
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              gap: '30px',
              marginBottom: '30px'
            }}>
              <div>
                <div style={{ marginBottom: '20px' }}>
                  <label style={{ display: 'block', marginBottom: '8px', fontWeight: 'bold' }}>
                    Username
                  </label>
                  <div style={{
                    background: 'rgba(255,255,255,0.1)',
                    padding: '12px',
                    borderRadius: '8px'
                  }}>
                    {user?.username}
                  </div>
                </div>

                <div style={{ marginBottom: '20px' }}>
                  <label style={{ display: 'block', marginBottom: '8px', fontWeight: 'bold' }}>
                    Email
                  </label>
                  <div style={{
                    background: 'rgba(255,255,255,0.1)',
                    padding: '12px',
                    borderRadius: '8px'
                  }}>
                    {user?.email}
                  </div>
                </div>
              </div>

              <div>
                <div style={{ marginBottom: '20px' }}>
                  <label style={{ display: 'block', marginBottom: '8px', fontWeight: 'bold' }}>
                    Current Balance
                  </label>
                  <div style={{
                    background: 'rgba(40, 167, 69, 0.2)',
                    padding: '12px',
                    borderRadius: '8px',
                    fontSize: '18px',
                    fontWeight: 'bold',
                    color: '#28a745'
                  }}>
                    ${user?.balance?.toFixed(2) || '0.00'}
                  </div>
                </div>

                <div style={{ marginBottom: '20px' }}>
                  <label style={{ display: 'block', marginBottom: '8px', fontWeight: 'bold' }}>
                    Member Since
                  </label>
                  <div style={{
                    background: 'rgba(255,255,255,0.1)',
                    padding: '12px',
                    borderRadius: '8px'
                  }}>
                    {new Date().toLocaleDateString()}
                  </div>
                </div>
              </div>
            </div>

            <div style={{
              background: 'rgba(255,255,255,0.05)',
              padding: '20px',
              borderRadius: '12px'
            }}>
              <h3 style={{ margin: '0 0 15px 0' }}>Game Statistics</h3>
              <div style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fit, minmax(120px, 1fr))',
                gap: '15px',
                textAlign: 'center'
              }}>
                <div>
                  <div style={{ fontSize: '24px', fontWeight: 'bold', color: '#667eea' }}>23</div>
                  <div style={{ fontSize: '12px', color: '#ccc' }}>Games Played</div>
                </div>
                <div>
                  <div style={{ fontSize: '24px', fontWeight: 'bold', color: '#28a745' }}>8</div>
                  <div style={{ fontSize: '12px', color: '#ccc' }}>Wins</div>
                </div>
                <div>
                  <div style={{ fontSize: '24px', fontWeight: 'bold', color: '#ffc107' }}>1234.5m</div>
                  <div style={{ fontSize: '12px', color: '#ccc' }}>Best Distance</div>
                </div>
                <div>
                  <div style={{ fontSize: '24px', fontWeight: 'bold', color: '#e74c3c' }}>34.8%</div>
                  <div style={{ fontSize: '12px', color: '#ccc' }}>Win Rate</div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};