import { FreeCamera, Mesh, Scene, Vector3 } from "@babylonjs/core";

const toRadians = (deg: number) => (deg * Math.PI) / 180;

export class CameraRig {
  private readonly camera: FreeCamera;
  private carMesh: Mesh | null = null;
  private currentPosition: Vector3;
  private currentLookAt: Vector3;
  private readonly smoothSpeed = 2.5; // Reduzido para eliminar tremor

  constructor(scene: Scene) {
    // Câmera posicionada atrás do carro
    this.camera = new FreeCamera("followCamera", new Vector3(0, 6, -10), scene);
    this.camera.fov = toRadians(75);   // Campo de visão amplo
    scene.activeCamera = this.camera;

    // Inicializar posições atuais
    this.currentPosition = new Vector3(0, 6, -10);
    this.currentLookAt = new Vector3(0, 0, 50);
  }

  follow(target: Mesh) {
    this.carMesh = target;
  }

  updateCameraPosition(carPosition: Vector3, carYaw: number, crashed: boolean, deltaTime: number = 1/60) {
    // Se crashou, para a câmera
    if (crashed) return;

    // Vista ajustada com ângulo mais baixo
    const distance = 14; // Distância reduzida para proximidade melhor
    const height = 8;    // Altura reduzida para ângulo mais baixo
    const minAbsoluteHeight = 6; // Altura mínima absoluta da câmera

    // Posição alvo da câmera atrás do carro
    const targetCameraX = carPosition.x - Math.sin(carYaw) * distance;
    const targetCameraZ = carPosition.z - Math.cos(carYaw) * distance;
    const baseCameraY = carPosition.y + height;

    // Garantir altura mínima absoluta para evitar que pistas baixas bloqueiem a visão
    const targetCameraY = Math.max(baseCameraY, minAbsoluteHeight);

    // Ponto alvo para onde olhar - à frente na direção do carro
    const lookAheadDistance = 25; // Distância reduzida para ângulo mais baixo
    const targetLookAtX = carPosition.x + Math.sin(carYaw) * lookAheadDistance;
    const targetLookAtZ = carPosition.z + Math.cos(carYaw) * lookAheadDistance;
    const targetLookAtY = carPosition.y + 1; // Olhar mais próximo ao chão

    const targetPosition = new Vector3(targetCameraX, targetCameraY, targetCameraZ);
    const targetLookAt = new Vector3(targetLookAtX, targetLookAtY, targetLookAtZ);

    // Interpolação suave mas responsiva da câmera
    const lerpFactor = Math.min(1, this.smoothSpeed * deltaTime);

    // Diferentes velocidades para posição e direção
    const positionFactor = lerpFactor; // Acompanha o carro normalmente
    const lookAtFactor = lerpFactor * 0.8; // LookAt segue a direção do carro

    this.currentPosition = Vector3.Lerp(this.currentPosition, targetPosition, positionFactor);
    this.currentLookAt = Vector3.Lerp(this.currentLookAt, targetLookAt, lookAtFactor);

    // Aplica as posições suavizadas
    this.camera.position.copyFrom(this.currentPosition);
    this.camera.setTarget(this.currentLookAt);
  }

  update(speed: number) {
    const minFov = 65;  // FOV mínimo mais alto
    const maxFov = 80;  // FOV máximo mais alto
    const clamped = Math.max(0, Math.min(speed / 25, 1));
    const desired = minFov + (maxFov - minFov) * clamped;
    this.camera.fov = toRadians(desired);
  }

  dispose() {
    this.camera.dispose();
  }
}