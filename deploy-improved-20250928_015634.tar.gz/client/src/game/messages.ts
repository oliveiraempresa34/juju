export const MESSAGE = {
  INPUT: "input",
  NAME: "name"
} as const;

export type MessageKey = keyof typeof MESSAGE;