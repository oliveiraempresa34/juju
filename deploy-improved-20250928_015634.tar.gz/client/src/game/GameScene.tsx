import React, { useEffect, useRef } from "react";
import { Color3, Color4, Engine, HemisphericLight, Scene, Vector3 } from "@babylonjs/core";
import { CameraRig } from "./CameraRig";
import { CarController } from "./CarController";
import { GhostsLayer } from "./GhostsLayer";
import { InputManager } from "./InputManager";
import { MultiplayerSync } from "./MultiplayerSync";
import { TrackGenerator } from "./TrackGenerator";
import { useRoomStore } from "../store/useRoom";
import { useGameStore } from "../store/useGame";
import { useScoreStore } from "../store/useScore";
import { LocalPhysics } from "./LocalPhysics";
import { GameOverModal } from "../components/GameOverModal";
import { ScoreDisplay } from "../components/ScoreDisplay";
import { SmokeSystem } from "./SmokeSystem";
import { StarField } from "./StarField";

export const GameScene: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const multiplayerRef = useRef<MultiplayerSync>();
  const localPhysicsRef = useRef<LocalPhysics>();
  const trackRef = useRef<TrackGenerator>();
  const cameraRigRef = useRef<CameraRig>();
  const smokeSystemRef = useRef<SmokeSystem>();
  const starFieldRef = useRef<StarField>();
  const lastDistanceRef = useRef(0);
  const lastTimestampRef = useRef(0);
  const hasLockedCameraRef = useRef(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) {
      return;
    }

    // Otimizações para mobile
    const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) || window.innerWidth < 768;

    const engine = new Engine(canvas, true, {
      adaptToDeviceRatio: true,
      antialias: !isMobile, // Desabilita anti-alias em mobile para performance
      powerPreference: "high-performance",
      preserveDrawingBuffer: false,
      stencil: false
    });
    const scene = new Scene(engine);
    scene.clearColor = new Color4(0.05, 0.08, 0.12, 1); // Azul escuro em vez de preto

    // Iluminação ambiente mais forte
    const light = new HemisphericLight("light", new Vector3(0, 1, 0), scene);
    light.intensity = 1.2;
    light.diffuse = new Color3(0.9, 0.9, 1.0);
    light.specular = new Color3(0.8, 0.8, 0.9);
    light.groundColor = new Color3(0.3, 0.3, 0.4);

    const carController = new CarController(scene);
    const cameraRig = new CameraRig(scene);
    const ghosts = new GhostsLayer(scene, carController);

    // Sistema de fumaça otimizado para mobile
    const smokeSystem = new SmokeSystem(scene);
    if (isMobile) {
      // Partículas muito intensas em mobile para fumaça bem visível
      smokeSystem.setMaxParticles(180);
      smokeSystem.setEmissionRate(0.005);
    }

    // Sistema de estrelas para fundo galáctico
    const starField = new StarField(scene, isMobile);

    // Usar seed consistente entre sessões
    const { seed } = useRoomStore.getState();
    const track = new TrackGenerator(scene, seed || Date.now());

    // Salvar referências
    trackRef.current = track;
    if (localPhysicsRef.current) {
      localPhysicsRef.current.setTrack(track);
    }
    cameraRigRef.current = cameraRig;
    smokeSystemRef.current = smokeSystem;
    starFieldRef.current = starField;

    lastTimestampRef.current = performance.now();

    scene.onBeforeRenderObservable.add(() => {
      const now = performance.now();
      const deltaSeconds = (now - lastTimestampRef.current) / 1000;
      lastTimestampRef.current = now;

      const { players, localPlayerId } = useRoomStore.getState();
      const activeIds = new Set<string>();

      // Update local physics for demo/practice mode
      const { gameMode } = useGameStore.getState();
      if ((gameMode === 'demo' || gameMode === 'practice') && localPhysicsRef.current && localPlayerId) {
        const currentPlayer = players[localPlayerId];
        if (currentPlayer) {
          const physicsState = localPhysicsRef.current.update();

          // Atualizar pontuação baseada na distância
          useScoreStore.getState().updateCurrentScore(physicsState.distance);

          // Verificar se o jogo acabou
          if (physicsState.gameOver) {
            useGameStore.getState().setGameOver(true);
            useGameStore.getState().setInGame(false);
            useGameStore.getState().updateDistance(physicsState.distance);
            // Atualizar melhor pontuação se necessário
            useScoreStore.getState().updateBestScore();
          }

          useRoomStore.getState().upsertPlayer({
            ...currentPlayer,
            x: physicsState.x,
            y: physicsState.y,
            z: physicsState.z,
            yaw: physicsState.yaw,
            pitch: physicsState.pitch,
            roll: physicsState.roll,
            distance: physicsState.distance
          });

          // Atualizar sistema de fumaça (baseado em clique na tela)
          if (smokeSystemRef.current) {
            const localState = localPhysicsRef.current?.getState();
            smokeSystemRef.current.update(
              new Vector3(physicsState.x, physicsState.y, physicsState.z),
              physicsState.yaw,
              deltaSeconds,
              localState?.turnStrength || 0, // Força da curva
              physicsState.pressing // Se está clicando na tela
            );
          }

          // Atualizar campo de estrelas
          if (starFieldRef.current) {
            starFieldRef.current.update(new Vector3(physicsState.x, physicsState.y, physicsState.z));
          }

          // Atualizar posição da câmera baseada no carro com suavização
          cameraRig.updateCameraPosition(
            new Vector3(physicsState.x, physicsState.y, physicsState.z),
            physicsState.yaw,
            physicsState.crashed,
            deltaSeconds
          );
        }
      }

      Object.values(players).forEach((player) => {
        carController.update(player);
        activeIds.add(player.id);
      });

      carController.prune(activeIds);
      ghosts.sync(players, localPlayerId);

      if (localPlayerId) {
        carController.setLocalPlayer(localPlayerId);
        const local = players[localPlayerId];
        if (local) {
          const mesh = carController.getMesh(localPlayerId);
          if (mesh && !hasLockedCameraRef.current) {
            cameraRig.follow(mesh);
            hasLockedCameraRef.current = true;
          }

          if (deltaSeconds > 0) {
            const distanceDelta = Math.max(0, local.distance - lastDistanceRef.current);
            const speed = distanceDelta / deltaSeconds;
            cameraRig.update(speed);
            lastDistanceRef.current = local.distance;
          }
        }
      }
    });

    engine.runRenderLoop(() => {
      scene.render();
    });

    // Otimização de redimensionamento para mobile
    const resize = () => {
      engine.resize();
      // Força atualização do canvas em mobile
      if (isMobile) {
        setTimeout(() => engine.resize(), 100);
      }
    };

    window.addEventListener("resize", resize);
    window.addEventListener("orientationchange", resize);

    // Redimensiona inicialmente
    setTimeout(resize, 100);

    return () => {
      window.removeEventListener("resize", resize);
      window.removeEventListener("orientationchange", resize);
      ghosts.dispose();
      carController.dispose();
      cameraRig.dispose();
      track.dispose();
      starField.dispose();
      scene.dispose();
      engine.dispose();
    };
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) {
      return;
    }

    const { gameMode, setConnectedToServer } = useGameStore.getState();

    // Only connect to multiplayer if mode is multiplayer
    if (gameMode === 'multiplayer' && !multiplayerRef.current) {
      const multiplayer = new MultiplayerSync();
      multiplayerRef.current = multiplayer;
      multiplayer.connect()
        .then(() => {
          setConnectedToServer(true);
        })
        .catch((error) => {
          console.error("Failed to join room", error);
          setConnectedToServer(false);
        });
    }

    // For demo/practice mode, create a mock local player
    if ((gameMode === 'demo' || gameMode === 'practice') && !useRoomStore.getState().localPlayerId) {
      const mockPlayerId = 'local_' + Math.random().toString(36).substr(2, 9);
      useRoomStore.getState().setLocalPlayerId(mockPlayerId);
      useRoomStore.getState().setSeed(Date.now());
      useRoomStore.getState().setStatus('connected');

      // Initialize local physics
      localPhysicsRef.current = new LocalPhysics(trackRef.current);

      // Marcar o jogo como iniciado
      useGameStore.getState().setInGame(true);
      useGameStore.getState().setGameOver(false);

      // Inicializar sistema de pontuação
      useScoreStore.getState().loadBestScore();
      useScoreStore.getState().resetCurrentScore();

      // Add a mock local player
      useRoomStore.getState().upsertPlayer({
        id: mockPlayerId,
        name: 'You',
        x: 0,
        y: 0.5,
        z: 0,
        yaw: 0,
        pressing: false,
        distance: 0,
        opacity: 1
      });
    }

    const input = new InputManager();
    input.attach(canvas, (inputState) => {
      if (gameMode === 'multiplayer') {
        multiplayerRef.current?.setPressing(inputState.accelerate);
      } else {
        // For demo/practice mode, update local player directly
        const { localPlayerId } = useRoomStore.getState();
        if (localPlayerId) {
          const currentPlayer = useRoomStore.getState().players[localPlayerId];
          if (currentPlayer) {
            useRoomStore.getState().upsertPlayer({
              ...currentPlayer,
              pressing: inputState.accelerate
            });
          }
        }
      }

      if (localPhysicsRef.current) {
        localPhysicsRef.current.setInput(inputState);
      }
    });

    return () => {
      input.detach();
      if (gameMode === 'multiplayer') {
        multiplayerRef.current?.dispose();
        multiplayerRef.current = undefined;
      }
    };
  }, []);

  return (
    <>
      <canvas
        ref={canvasRef}
        style={{
          width: "100%",
          height: "100%",
          display: "block",
          touchAction: "manipulation",
          position: "absolute",
          top: 0,
          left: 0,
          userSelect: "none",
          WebkitUserSelect: "none",
          WebkitTouchCallout: "none",
          WebkitTapHighlightColor: "transparent"
        }}
      />
      <ScoreDisplay />
      <GameOverModal localPhysicsRef={localPhysicsRef} trackRef={trackRef} />
    </>
  );
};
