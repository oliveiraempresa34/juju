import { Client, Room } from "colyseus.js";
import { MESSAGE } from "./messages";
import { PlayerSnapshot, useRoomStore } from "../store/useRoom";

interface DriftRoomState {
  players: any;
  seed: number;
}

export class MultiplayerSync {
  private readonly endpoint: string;
  private readonly client: Client;
  private room?: Room<DriftRoomState>;

  constructor() {
    this.endpoint = import.meta.env.VITE_WS_URL || "ws://localhost:2567";
    this.client = new Client(this.endpoint);
  }

  async connect() {
    const store = useRoomStore.getState();
    store.setStatus("connecting");

    try {
      this.room = await this.client.joinOrCreate<DriftRoomState>("drift");
      store.setStatus("connected");
      store.setLocalPlayerId(this.room.sessionId);
      store.setSeed(this.room.state?.seed ?? Date.now());

      this.room.onMessage("seed", ({ seed }) => {
        useRoomStore.getState().setSeed(seed);
      });

      this.room.onLeave(() => {
        useRoomStore.getState().reset();
      });

      this.bindStateListeners();
      this.room.send(MESSAGE.NAME, { name: `Pilot-${this.room.sessionId.slice(0, 4)}` });
    } catch (error) {
      const message = error instanceof Error ? error.message : "Failed to connect";
      store.setStatus("error", message);
      throw error;
    }
  }

  setPressing(pressing: boolean) {
    if (!this.room) {
      return;
    }
    this.room.send(MESSAGE.INPUT, { pressing });
  }

  dispose() {
    this.room?.leave();
    this.room = undefined;
  }

  private bindStateListeners() {
    const room = this.room;
    if (!room) {
      return;
    }

    const players = room.state.players;
    if (!players) {
      return;
    }

    players.onAdd = (player: any, key: string) => {
      this.pushSnapshot(player);
      player.onChange(() => {
        this.pushSnapshot(player);
      });
      player.onRemove(() => {
        useRoomStore.getState().removePlayer(key);
      });
    };

    players.onRemove = (_player: any, key: string) => {
      useRoomStore.getState().removePlayer(key);
    };

    players.forEach((player: any) => this.pushSnapshot(player));
  }

  private pushSnapshot(player: any) {
    if (!player || typeof player !== "object") {
      return;
    }

    const snapshot: PlayerSnapshot = {
      id: player.id ?? "",
      name: player.name ?? "Driver",
      x: player.x ?? 0,
      y: player.y ?? 0,
      z: player.z ?? 0,
      yaw: player.yaw ?? 0,
      pressing: Boolean(player.pressing),
      distance: player.distance ?? 0,
      opacity: player.opacity ?? 1
    };

    useRoomStore.getState().upsertPlayer(snapshot);
  }
}