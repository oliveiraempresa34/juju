import { Color3, Matrix, Mesh, MeshBuilder, Scene, StandardMaterial, Vector3 } from "@babylonjs/core";

export enum SegmentType {
  STRAIGHT_SHORT = "straight_short",
  STRAIGHT_MEDIUM = "straight_medium",
  CURVE_GENTLE_RIGHT = "curve_gentle_right",
  CURVE_MEDIUM_RIGHT = "curve_medium_right",
  CURVE_SHARP_RIGHT = "curve_sharp_right"
}

interface SegmentDefinition {
  type: SegmentType;
  length: number;
  curvature: number;
  banking: number;
  widthVariation: number;
  difficulty: number;
  rightTurnBias: number;
}

interface SegmentBlueprint {
  centerline: Vector3[];
  leftEdge: Vector3[];
  rightEdge: Vector3[];
  deltaHeading: number;
  length: number;
}

interface TrackSegment {
  id: string;
  definition: SegmentDefinition;
  startPosition: Vector3;
  endPosition: Vector3;
  startHeading: number;
  endHeading: number;
  mesh?: Mesh;
  barriers: Mesh[];
  centerline: Vector3[];
  leftEdge: Vector3[];
  rightEdge: Vector3[];
  cumulativeStart: number;
  cumulativeEnd: number;
  accumulatedLengths: number[];
}

export interface TrackSample {
  position: Vector3;
  forward: Vector3;
  right: Vector3;
  width: number;
  segmentId: string;
}

export class TrackGenerator {
  private segments: TrackSegment[] = [];
  private barriers: Mesh[] = [];
  private seed: number;
  private rng: () => number;
  private currentPosition: Vector3;
  private currentHeading: number;
  private segmentCount: number;
  private totalLength: number;
  private cumulativeHeight: number = 0; // Rastrear altura acumulativa para evitar sobreposição
  private readonly trackWidth = 10; // Pista mais larga para melhor jogabilidade
  private readonly lookAheadDistance = 200;
  private readonly blueprintCache = new Map<SegmentType, SegmentBlueprint>();

  private readonly segmentDefinitions: SegmentDefinition[] = [
    {
      type: SegmentType.STRAIGHT_SHORT,
      length: 60,
      curvature: 0,
      banking: 0,
      widthVariation: 1.0,
      difficulty: 0.1,
      rightTurnBias: 0.5
    },
    {
      type: SegmentType.STRAIGHT_MEDIUM,
      length: 80,
      curvature: 0,
      banking: 0,
      widthVariation: 1.0,
      difficulty: 0.1,
      rightTurnBias: 0.5
    },
    {
      type: SegmentType.CURVE_GENTLE_RIGHT,
      length: 8,
      curvature: Math.PI / 0.3 / 8, // Curva ultra insana (600 graus - quase 2 voltas)
      banking: Math.PI / 2.2, // Bancada quase vertical (82 graus)
      widthVariation: 1.0,
      difficulty: 0.95,
      rightTurnBias: 1.0
    },
    {
      type: SegmentType.CURVE_MEDIUM_RIGHT,
      length: 6,
      curvature: Math.PI / 0.25 / 6, // Curva mega loop (720 graus - 2 voltas completas)
      banking: Math.PI / 2.0, // Bancada vertical (90 graus)
      widthVariation: 1.0,
      difficulty: 0.99,
      rightTurnBias: 1.0
    },
    {
      type: SegmentType.CURVE_SHARP_RIGHT,
      length: 5,
      curvature: Math.PI / 0.2 / 5, // Curva impossível extrema (900 graus - 2.5 voltas)
      banking: Math.PI / 1.8, // Bancada sobre-vertical (100 graus)
      widthVariation: 1.0,
      difficulty: 1.0,
      rightTurnBias: 1.0
    }
  ];

  constructor(private readonly scene: Scene, seed?: number) {
    this.seed = seed || Date.now();
    this.rng = this.createPRNG(this.seed);
    this.currentPosition = new Vector3(0, 0, 0);
    this.currentHeading = 0;
    this.segmentCount = 0;
    this.totalLength = 0;
    this.cumulativeHeight = 0; // Inicializar altura cumulativa
    this.generateInitialSegments();
  }

  private createPRNG(seed: number): () => number {
    let state = seed;
    return () => {
      state = (state * 1664525 + 1013904223) % Math.pow(2, 32);
      return state / Math.pow(2, 32);
    };
  }

  private generateInitialSegments() {
    // Primeiro segmento sempre reto
    const straightDef = this.segmentDefinitions.find((s) => s.type === SegmentType.STRAIGHT_MEDIUM);
    if (straightDef) {
      this.createSegment(straightDef);
    }

    // Gera segmentos subsequentes com curvas progressivamente mais fechadas
    while (this.totalLength < this.lookAheadDistance) {
      this.generateNextSegment();
    }
  }

  private generateNextSegment() {
    const segmentType = this.chooseSegmentType();
    const definition = this.segmentDefinitions.find((s) => s.type === segmentType);
    if (!definition) {
      return;
    }
    this.createSegment(definition);
  }

  private createSegment(definition: SegmentDefinition) {
    // Aplicar altura cumulativa à posição inicial do segmento
    const startPosition = this.currentPosition.clone();
    startPosition.y += this.cumulativeHeight;

    const segment: TrackSegment = {
      id: `segment_${this.segmentCount}`,
      definition,
      startPosition: startPosition,
      endPosition: new Vector3(),
      startHeading: this.currentHeading,
      endHeading: this.currentHeading,
      barriers: [],
      centerline: [],
      leftEdge: [],
      rightEdge: [],
      cumulativeStart: this.totalLength,
      cumulativeEnd: this.totalLength,
      accumulatedLengths: []
    };

    this.buildSegmentGeometry(segment);
    this.createSegmentMesh(segment);
    this.createSegmentBarriers(segment);

    // Atualizar altura cumulativa de forma controlada para pistas mais lisas
    if (definition.banking > 0) {
      this.cumulativeHeight += definition.length * 0.6; // Acumular altura moderada para subidas suaves
    }

    this.currentPosition = segment.endPosition.clone();
    // Aplicar a altura cumulativa à posição atual
    this.currentPosition.y += this.cumulativeHeight;

    this.currentHeading = segment.endHeading;
    this.segmentCount++;
    this.totalLength = segment.cumulativeEnd;
    this.segments.push(segment);
  }

  private chooseSegmentType(): SegmentType {
    const segmentIndex = this.segments.length;

    // Primeiro segmento sempre reto
    if (segmentIndex === 0) {
      return SegmentType.STRAIGHT_MEDIUM;
    }

    // Apenas curvas à direita e retas
    const rand = this.rng();

    if (segmentIndex < 3) {
      // Curvas suaves no início
      return SegmentType.CURVE_GENTLE_RIGHT;
    } else if (segmentIndex < 6) {
      // Mais curvas, menos retas
      if (rand < 0.85) return SegmentType.CURVE_MEDIUM_RIGHT;
      else return SegmentType.STRAIGHT_SHORT;
    } else {
      // Predominantemente curvas
      if (rand < 0.4) return SegmentType.CURVE_SHARP_RIGHT;
      else if (rand < 0.75) return SegmentType.CURVE_MEDIUM_RIGHT;
      else if (rand < 0.95) return SegmentType.CURVE_GENTLE_RIGHT;
      else return SegmentType.STRAIGHT_SHORT;
    }
  }

  private getBlueprint(definition: SegmentDefinition): SegmentBlueprint {
    const cached = this.blueprintCache.get(definition.type);
    if (cached) {
      return cached;
    }

    const subdivisions = Math.max(20, Math.ceil(definition.length / 2));
    const step = definition.length / subdivisions;
    const curvature = definition.curvature;
    const halfWidth = this.trackWidth / 2;

    const centerline: Vector3[] = [];
    const leftEdge: Vector3[] = [];
    const rightEdge: Vector3[] = [];

    for (let i = 0; i <= subdivisions; i++) {
      const s = step * i;
      let position: Vector3;
      let yaw = curvature * s;

      if (Math.abs(curvature) < 1e-6) {
        position = new Vector3(0, 0, s);
        yaw = 0;
      } else {
        const angle = curvature * s;
        const invCurvature = 1 / curvature;

        // Adiciona elevação moderada apenas para curvas acentuadas
        const elevationGain = definition.banking > 0 ? s * 0.8 : 0; // Elevação moderada para subidas controladas

        position = new Vector3(
          invCurvature * (1 - Math.cos(angle)),
          elevationGain, // Altura do viaduto
          invCurvature * Math.sin(angle)
        );
        yaw = angle;
      }

      const forward = new Vector3(Math.sin(yaw), 0, Math.cos(yaw));
      const right = new Vector3(forward.z, 0, -forward.x).normalize();

      // Aplica bancada (inclinação lateral) para curvas
      const bankingAngle = definition.banking * (curvature !== 0 ? 1 : 0);
      const bankingCos = Math.cos(bankingAngle);
      const bankingSin = Math.sin(bankingAngle);

      // Calcula offset com bancada aplicada
      const lateralOffset = right.scale(halfWidth);
      const verticalOffset = new Vector3(0, halfWidth * bankingSin * 0.35, 0);

      const leftPoint = new Vector3(
        position.x - lateralOffset.x * bankingCos,
        position.y - verticalOffset.y,
        position.z - lateralOffset.z * bankingCos
      );
      const rightPoint = new Vector3(
        position.x + lateralOffset.x * bankingCos,
        position.y + verticalOffset.y,
        position.z + lateralOffset.z * bankingCos
      );

      centerline.push(position);
      leftEdge.push(leftPoint);
      rightEdge.push(rightPoint);
    }

    // Aplicar suavização final para eliminar todas as ondulações
    this.smoothPath(centerline);
    this.smoothPath(leftEdge);
    this.smoothPath(rightEdge);

    const blueprint: SegmentBlueprint = {
      centerline,
      leftEdge,
      rightEdge,
      deltaHeading: curvature * definition.length,
      length: definition.length
    };

    this.blueprintCache.set(definition.type, blueprint);
    return blueprint;
  }

  private buildSegmentGeometry(segment: TrackSegment) {
    const blueprint = this.getBlueprint(segment.definition);
    const rotation = Matrix.RotationY(segment.startHeading);
    const transformPoint = (point: Vector3) => Vector3.TransformCoordinates(point, rotation).add(segment.startPosition);

    let centerline = blueprint.centerline.map(transformPoint);
    let leftEdge = blueprint.leftEdge.map(transformPoint);
    let rightEdge = blueprint.rightEdge.map(transformPoint);

    // Garante continuidade ABSOLUTA com o segmento anterior
    if (this.segments.length > 0) {
      const prevSegment = this.segments[this.segments.length - 1];
      const prevEndCenter = prevSegment.centerline[prevSegment.centerline.length - 1];
      const prevEndLeft = prevSegment.leftEdge[prevSegment.leftEdge.length - 1];
      const prevEndRight = prevSegment.rightEdge[prevSegment.rightEdge.length - 1];

      // Ajusta pontos iniciais para match perfeito
      const centerOffset = prevEndCenter.subtract(centerline[0]);
      const leftOffset = prevEndLeft.subtract(leftEdge[0]);
      const rightOffset = prevEndRight.subtract(rightEdge[0]);

      // Aplica offset a todos os pontos
      centerline = centerline.map(point => point.add(centerOffset));
      leftEdge = leftEdge.map(point => point.add(leftOffset));
      rightEdge = rightEdge.map(point => point.add(rightOffset));

      // Força o primeiro ponto a ser exatamente igual ao último do anterior
      centerline[0] = prevEndCenter.clone();
      leftEdge[0] = prevEndLeft.clone();
      rightEdge[0] = prevEndRight.clone();

      // Suaviza a transição de altura para eliminar ondulações desnecessárias
      const transitionPoints = Math.min(8, centerline.length); // Menos pontos para maior suavidade
      const maxYDelta = 0.5; // Mudanças muito pequenas de altura para pista lisa

      for (let i = 1; i < transitionPoints; i++) {
        const lerpFactor = Math.sin((i / transitionPoints) * Math.PI * 0.5); // Curva senoidal suave
        const targetY = prevEndCenter.y + (centerline[i].y - prevEndCenter.y) * lerpFactor;

        // Limita mudanças muito pequenas de altura para pista uniforme
        const prevY = centerline[i - 1].y;
        const maxAllowedY = prevY + maxYDelta;
        const minAllowedY = prevY - maxYDelta;

        const smoothY = Math.max(minAllowedY, Math.min(maxAllowedY, targetY));

        centerline[i].y = smoothY;
        leftEdge[i].y = smoothY + (leftEdge[i].y - centerline[i].y) * 0.1; // Inclinação lateral mínima
        rightEdge[i].y = smoothY + (rightEdge[i].y - centerline[i].y) * 0.1;
      }

      // Suavização adicional para eliminar ondulações restantes
      for (let i = transitionPoints; i < centerline.length - 1; i++) {
        const prevY = centerline[i - 1].y;
        const currentY = centerline[i].y;
        const nextY = centerline[i + 1].y;

        // Aplicar filtro de média móvel para suavidade extrema
        const smoothedY = (prevY + currentY + nextY) / 3;
        centerline[i].y = smoothedY;
        leftEdge[i].y = smoothedY + (leftEdge[i].y - centerline[i].y) * 0.1;
        rightEdge[i].y = smoothedY + (rightEdge[i].y - centerline[i].y) * 0.1;
      }

      // Atualiza a posição inicial do segmento
      segment.startPosition = centerline[0].clone();
    }

    const accumulated: number[] = [0];
    for (let i = 1; i < centerline.length; i++) {
      const dist = Vector3.Distance(centerline[i], centerline[i - 1]);
      accumulated.push(accumulated[i - 1] + dist);
    }

    const totalLength = accumulated[accumulated.length - 1];

    segment.centerline = centerline;
    segment.leftEdge = leftEdge;
    segment.rightEdge = rightEdge;
    segment.accumulatedLengths = accumulated;
    segment.endPosition = centerline[centerline.length - 1].clone();
    segment.endHeading = this.normalizeAngle(segment.startHeading + blueprint.deltaHeading);
    segment.cumulativeEnd = segment.cumulativeStart + totalLength;
  }

  private createSegmentMesh(segment: TrackSegment) {
    const pathArray = [segment.leftEdge, segment.rightEdge];

    const trackMesh = MeshBuilder.CreateRibbon(
      segment.id,
      { pathArray, sideOrientation: Mesh.DOUBLESIDE, updatable: false },
      this.scene
    );

    const material = new StandardMaterial(`${segment.id}_material`, this.scene);

    // Cor diferenciada para início e fim dos segmentos
    const isFirstSegment = segment.id === 'segment_0';
    const isConnectionPoint = this.segments.length > 0;

    // Cor uniforme cinza escuro para todas as pistas
    material.diffuseColor = new Color3(0.15, 0.15, 0.18); // Cinza escuro uniforme

    if (isFirstSegment) {
      // Adicionar padrão xadrez no primeiro segmento (mantém cor cinza)
      this.createCheckerboardPattern(segment);
    }

    material.specularColor = new Color3(0.05, 0.05, 0.08);
    trackMesh.material = material;

    segment.mesh = trackMesh;

    // Criar faixas amarelas centrais
    this.createCenterLaneMarkings(segment);
  }

  private createCheckerboardPattern(segment: TrackSegment) {
    // Criar padrão xadrez com 4 fileiras cruzando a pista
    const rows = 4;
    const cols = 8; // 8 colunas para ter largura adequada
    const squareSize = this.trackWidth / cols;

    // Posição no início do segmento, na frente do carro
    const segmentStart = segment.centerline[Math.floor(segment.centerline.length * 0.3)]; // 30% do segmento
    const startX = segmentStart.x - (this.trackWidth / 2);
    const startZ = segmentStart.z - (rows * squareSize / 2);

    for (let row = 0; row < rows; row++) {
      for (let col = 0; col < cols; col++) {
        // Padrão xadrez: alternar cores baseado na soma das coordenadas
        const isWhite = (row + col) % 2 === 0;

        if (isWhite) {
          // Criar apenas os quadrados brancos (pretos são o "buraco" na pista verde)
          const square = MeshBuilder.CreateGround(
            `checker_${segment.id}_${row}_${col}`,
            { width: squareSize * 0.9, height: squareSize * 0.9 }, // 90% do tamanho para criar espaçamento
            this.scene
          );

          // Posicionar o quadrado
          square.position.x = startX + (col * squareSize) + (squareSize / 2);
          square.position.y = segmentStart.y + 0.01; // Ligeiramente acima da pista
          square.position.z = startZ + (row * squareSize) + (squareSize / 2);

          // Material branco para os quadrados
          const checkerMaterial = new StandardMaterial(`checker_mat_${segment.id}_${row}_${col}`, this.scene);
          checkerMaterial.diffuseColor = new Color3(0.9, 0.9, 0.9); // Branco
          checkerMaterial.specularColor = new Color3(0.1, 0.1, 0.1);
          square.material = checkerMaterial;

          // Adicionar às barreiras para ser removido junto com o segmento
          segment.barriers.push(square);
        }
      }
    }
  }

  private createCenterLaneMarkings(segment: TrackSegment) {
    const { centerline } = segment;
    if (centerline.length < 2) return;

    // Parâmetros das faixas - completamente planas
    const laneWidth = 0.08; // Largura uniforme das faixas
    const laneGap = 0.16; // Distância entre as duas faixas

    // Criar duas faixas como pequenos grounds planos
    for (let i = 0; i < centerline.length - 1; i++) {
      const point1 = centerline[i];
      const point2 = centerline[i + 1];

      // Calcular direção e comprimento do segmento
      const direction = point2.subtract(point1);
      const segmentLength = direction.length();
      const normalizedDirection = direction.normalize();
      const perpendicular = new Vector3(-normalizedDirection.z, 0, normalizedDirection.x);

      // Ponto médio do segmento
      const midPoint = Vector3.Lerp(point1, point2, 0.5);

      // Criar faixa esquerda
      const leftLaneCenter = midPoint.add(perpendicular.scale(laneGap / 2));
      leftLaneCenter.y += 0.002; // Elevar ligeiramente

      const leftLaneMesh = MeshBuilder.CreateGround(
        `${segment.id}_left_lane_${i}`,
        { width: laneWidth, height: segmentLength },
        this.scene
      );

      leftLaneMesh.position = leftLaneCenter;
      leftLaneMesh.rotation.y = Math.atan2(normalizedDirection.x, normalizedDirection.z);

      // Criar faixa direita
      const rightLaneCenter = midPoint.subtract(perpendicular.scale(laneGap / 2));
      rightLaneCenter.y += 0.002; // Elevar ligeiramente

      const rightLaneMesh = MeshBuilder.CreateGround(
        `${segment.id}_right_lane_${i}`,
        { width: laneWidth, height: segmentLength },
        this.scene
      );

      rightLaneMesh.position = rightLaneCenter;
      rightLaneMesh.rotation.y = Math.atan2(normalizedDirection.x, normalizedDirection.z);

      // Material amarelo simples e seguro
      const laneMaterial = new StandardMaterial(`${segment.id}_lane_mat_${i}`, this.scene);
      laneMaterial.diffuseColor = new Color3(1.0, 1.0, 0.0); // Amarelo puro
      laneMaterial.emissiveColor = new Color3(0.1, 0.1, 0.0); // Leve emissão
      laneMaterial.backFaceCulling = false; // Visível dos dois lados

      leftLaneMesh.material = laneMaterial;
      rightLaneMesh.material = laneMaterial;

      // Desabilitar física e colisões
      leftLaneMesh.checkCollisions = false;
      leftLaneMesh.isPickable = false;
      rightLaneMesh.checkCollisions = false;
      rightLaneMesh.isPickable = false;

      segment.barriers.push(leftLaneMesh, rightLaneMesh);
    }
  }

  private createSegmentBarriers(segment: TrackSegment) {
    if (segment.leftEdge.length === 0 || segment.rightEdge.length === 0) {
      return;
    }

    const leftBarrier = MeshBuilder.CreateTube(
      `${segment.id}_barrier_left`,
      {
        path: segment.leftEdge.map((p) => p.clone().add(new Vector3(0, 0.75, 0))),
        radius: 0.18,
        tessellation: 8,
        sideOrientation: Mesh.DOUBLESIDE
      },
      this.scene
    );

    const rightBarrier = MeshBuilder.CreateTube(
      `${segment.id}_barrier_right`,
      {
        path: segment.rightEdge.map((p) => p.clone().add(new Vector3(0, 0.75, 0))),
        radius: 0.18,
        tessellation: 8,
        sideOrientation: Mesh.DOUBLESIDE
      },
      this.scene
    );

    const barrierMaterial = new StandardMaterial(`${segment.id}_barrier_material`, this.scene);
    barrierMaterial.diffuseColor = new Color3(0.8, 0.1, 0.1);
    barrierMaterial.emissiveColor = new Color3(0.25, 0.05, 0.05);

    leftBarrier.material = barrierMaterial;
    rightBarrier.material = barrierMaterial;

    segment.barriers.push(leftBarrier, rightBarrier);
    this.barriers.push(leftBarrier, rightBarrier);
  }

  public syncToDistance(distance: number) {
    while (distance + this.lookAheadDistance > this.totalLength) {
      this.generateNextSegment();
    }

    const safeDistance = Math.max(0, distance - 120);

    const survivors: TrackSegment[] = [];
    this.segments.forEach((segment) => {
      if (segment.cumulativeEnd < safeDistance) {
        segment.mesh?.dispose(false, true);
        segment.barriers.forEach((barrier) => barrier.dispose(false, true));
        return;
      }
      survivors.push(segment);
    });

    this.segments = survivors;
  }

  public getSampleAtDistance(distance: number): TrackSample | null {
    if (this.segments.length === 0) {
      return null;
    }

    for (const segment of this.segments) {
      if (distance < segment.cumulativeStart || distance > segment.cumulativeEnd) {
        continue;
      }

      const localDistance = distance - segment.cumulativeStart;
      return this.sampleSegment(segment, localDistance);
    }

    const last = this.segments[this.segments.length - 1];
    return this.sampleSegment(last, last.accumulatedLengths[last.accumulatedLengths.length - 1]);
  }

  public getClosestSample(position: Vector3): TrackSample | null {
    let closest: TrackSample | null = null;
    let closestDistanceSq = Number.POSITIVE_INFINITY;

    for (const segment of this.segments) {
      const { centerline } = segment;
      for (let i = 0; i < centerline.length - 1; i++) {
        const a = centerline[i];
        const b = centerline[i + 1];

        const ab = b.clone().subtract(a);
        const abXZ = new Vector3(ab.x, 0, ab.z);
        const lengthSq = abXZ.lengthSquared();
        if (lengthSq < 1e-6) {
          continue;
        }

        const toPoint = new Vector3(position.x - a.x, 0, position.z - a.z);
        let t = Vector3.Dot(toPoint, abXZ) / lengthSq;
        t = Math.max(0, Math.min(1, t));

        const pointX = a.x + ab.x * t;
        const pointY = a.y + (b.y - a.y) * t;
        const pointZ = a.z + ab.z * t;

        const leftPoint = Vector3.Lerp(segment.leftEdge[i], segment.leftEdge[i + 1], t);
        const rightPoint = Vector3.Lerp(segment.rightEdge[i], segment.rightEdge[i + 1], t);

        const diffX = position.x - pointX;
        const diffZ = position.z - pointZ;
        const distSq = diffX * diffX + diffZ * diffZ;

        if (distSq < closestDistanceSq) {
          const forwardVec = b.clone().subtract(a).normalize();
          const lateral = rightPoint.clone().subtract(leftPoint);
          const width = lateral.length();
          const right = lateral.normalize();
          closestDistanceSq = distSq;
          closest = {
            position: new Vector3(pointX, pointY, pointZ),
            forward: forwardVec,
            right,
            width,
            segmentId: segment.id
          };
        }
      }
    }

    return closest;
  }

  private sampleSegment(segment: TrackSegment, localDistance: number): TrackSample {
    const { centerline, accumulatedLengths } = segment;

    if (centerline.length < 2) {
      return {
        position: segment.endPosition.clone(),
        forward: new Vector3(Math.sin(segment.endHeading), 0, Math.cos(segment.endHeading)),
        right: new Vector3(-Math.cos(segment.endHeading), 0, Math.sin(segment.endHeading)),
        width: this.trackWidth,
        segmentId: segment.id
      };
    }

    let index = 1;
    for (; index < accumulatedLengths.length; index++) {
      if (accumulatedLengths[index] >= localDistance) {
        break;
      }
    }

    const prevIndex = Math.max(0, index - 1);
    const prevPoint = centerline[prevIndex];
    const nextPoint = centerline[Math.min(index, centerline.length - 1)];
    const prevAccum = accumulatedLengths[prevIndex];
    const nextAccum = accumulatedLengths[Math.min(index, accumulatedLengths.length - 1)];
    const span = Math.max(0.001, nextAccum - prevAccum);
    const t = Math.min(1, Math.max(0, (localDistance - prevAccum) / span));
    const position = Vector3.Lerp(prevPoint, nextPoint, t);

    const forwardVec = nextPoint.clone().subtract(prevPoint).normalize();
    const leftPoint = Vector3.Lerp(segment.leftEdge[prevIndex], segment.leftEdge[Math.min(index, segment.leftEdge.length - 1)], t);
    const rightPoint = Vector3.Lerp(segment.rightEdge[prevIndex], segment.rightEdge[Math.min(index, segment.rightEdge.length - 1)], t);
    const lateral = rightPoint.clone().subtract(leftPoint);
    const width = lateral.length();
    const right = lateral.normalize();

    return {
      position,
      forward: forwardVec,
      right,
      width,
      segmentId: segment.id
    };
  }

  public checkBounds(position: Vector3, carHalfWidth: number): boolean {
    // Encontra o segmento mais próximo
    let closestSegment: TrackSegment | null = null;
    let minDistanceSq = Number.POSITIVE_INFINITY;

    for (const segment of this.segments) {
      for (let i = 0; i < segment.centerline.length; i++) {
        const centerPoint = segment.centerline[i];
        const distSq = Vector3.DistanceSquared(position, centerPoint);
        if (distSq < minDistanceSq) {
          minDistanceSq = distSq;
          closestSegment = segment;
        }
      }
    }

    if (!closestSegment) {
      return true;
    }

    // Verifica colisão detalhada com as bordas do segmento
    return this.checkSegmentBounds(position, carHalfWidth, closestSegment);
  }

  private checkSegmentBounds(position: Vector3, carHalfWidth: number, segment: TrackSegment): boolean {
    const carPos2D = new Vector3(position.x, 0, position.z);
    const barrierThickness = 0.18;
    const collisionThreshold = carHalfWidth + barrierThickness;

    // Verifica colisão com borda esquerda (barreira vermelha)
    for (let i = 0; i < segment.leftEdge.length - 1; i++) {
      const p1 = new Vector3(segment.leftEdge[i].x, 0, segment.leftEdge[i].z);
      const p2 = new Vector3(segment.leftEdge[i + 1].x, 0, segment.leftEdge[i + 1].z);

      const distance = this.distanceToLineSegment(carPos2D, p1, p2);
      if (distance < collisionThreshold) {
        return false; // Colisão com barreira esquerda
      }
    }

    // Verifica colisão com borda direita (barreira vermelha)
    for (let i = 0; i < segment.rightEdge.length - 1; i++) {
      const p1 = new Vector3(segment.rightEdge[i].x, 0, segment.rightEdge[i].z);
      const p2 = new Vector3(segment.rightEdge[i + 1].x, 0, segment.rightEdge[i + 1].z);

      const distance = this.distanceToLineSegment(carPos2D, p1, p2);
      if (distance < collisionThreshold) {
        return false; // Colisão com barreira direita
      }
    }

    return true; // Nenhuma colisão
  }

  private distanceToLineSegment(point: Vector3, lineStart: Vector3, lineEnd: Vector3): number {
    const line = lineEnd.subtract(lineStart);
    const lineLength = line.length();

    if (lineLength < 0.001) {
      return Vector3.Distance(point, lineStart);
    }

    const lineDirection = line.normalize();
    const toPoint = point.subtract(lineStart);
    const projection = Vector3.Dot(toPoint, lineDirection);

    // Clamp projeção para o segmento
    const clampedProjection = Math.max(0, Math.min(lineLength, projection));
    const closestPointOnLine = lineStart.add(lineDirection.scale(clampedProjection));

    return Vector3.Distance(point, closestPointOnLine);
  }

  getHalfWidth() {
    return this.trackWidth / 2;
  }

  getTrackCenterPosition(): Vector3 {
    if (this.segments.length === 0) {
      return new Vector3(0, 0, 0);
    }
    const segment = this.segments[0];
    return segment.centerline[0]?.clone() ?? new Vector3(0, 0, 0);
  }

  resetTrack() {
    this.segments.forEach((segment) => {
      segment.mesh?.dispose(false, true);
      segment.barriers.forEach((barrier) => barrier.dispose(false, true));
    });
    this.segments = [];
    this.barriers = [];
    this.currentPosition = new Vector3(0, 0, 0);
    this.currentHeading = 0;
    this.segmentCount = 0;
    this.totalLength = 0;
    this.cumulativeHeight = 0; // Reset altura cumulativa
    this.generateInitialSegments();
  }

  dispose() {
    this.resetTrack();
  }

  private smoothPath(path: Vector3[]) {
    if (path.length < 3) return;

    // Aplicar filtro de suavização múltiplas vezes para eliminar ondulações
    for (let pass = 0; pass < 2; pass++) {
      for (let i = 1; i < path.length - 1; i++) {
        const prev = path[i - 1];
        const current = path[i];
        const next = path[i + 1];

        // Suavização apenas na altura (Y) para manter forma lateral
        const smoothedY = (prev.y + current.y * 2 + next.y) / 4; // Peso maior no ponto atual
        path[i].y = smoothedY;
      }
    }
  }

  private normalizeAngle(value: number) {
    let angle = value;
    while (angle > Math.PI) angle -= Math.PI * 2;
    while (angle < -Math.PI) angle += Math.PI * 2;
    return angle;
  }
}
