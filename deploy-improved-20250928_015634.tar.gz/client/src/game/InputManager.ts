import type { PlayerInputState } from "./LocalPhysics";

type InputCallback = (input: PlayerInputState) => void;

export class InputManager {
  private canvas?: HTMLCanvasElement | null;
  private callback?: InputCallback;

  private accelerating = false;
  private leftActive = false;
  private rightActive = false;
  private pointerActive = false;
  private pointerSteering = 0;

  attach(canvas: HTMLCanvasElement, callback: InputCallback) {
    this.detach();
    this.canvas = canvas;
    this.callback = callback;

    canvas.addEventListener("mousedown", this.handleMouseDown);
    canvas.addEventListener("mouseup", this.handleMouseUp);
    canvas.addEventListener("mouseleave", this.handleMouseLeave);
    canvas.addEventListener("mousemove", this.handleMouseMove);
    canvas.addEventListener("touchstart", this.handleTouchStart, { passive: false });
    canvas.addEventListener("touchend", this.handleTouchEnd, { passive: false });
    canvas.addEventListener("touchcancel", this.handleTouchEnd, { passive: false });
    canvas.addEventListener("touchmove", this.handleTouchMove, { passive: false });

    window.addEventListener("keydown", this.handleKeyDown, { passive: false });
    window.addEventListener("keyup", this.handleKeyUp, { passive: false });

    this.emit();
  }

  detach() {
    if (!this.canvas) {
      return;
    }

    this.canvas.removeEventListener("mousedown", this.handleMouseDown);
    this.canvas.removeEventListener("mouseup", this.handleMouseUp);
    this.canvas.removeEventListener("mouseleave", this.handleMouseLeave);
    this.canvas.removeEventListener("mousemove", this.handleMouseMove);
    this.canvas.removeEventListener("touchstart", this.handleTouchStart);
    this.canvas.removeEventListener("touchend", this.handleTouchEnd);
    this.canvas.removeEventListener("touchcancel", this.handleTouchEnd);
    this.canvas.removeEventListener("touchmove", this.handleTouchMove);

    window.removeEventListener("keydown", this.handleKeyDown);
    window.removeEventListener("keyup", this.handleKeyUp);

    this.canvas = undefined;
    this.callback = undefined;
    this.pointerActive = false;
    this.pointerSteering = 0;
  }

  private emit() {
    this.callback?.({
      accelerate: this.accelerating,
      steering: this.computeSteering()
    });
  }

  private computeSteering() {
    if (this.pointerActive) {
      return this.pointerSteering;
    }

    if (this.leftActive && !this.rightActive) {
      return -1;
    }

    if (this.rightActive && !this.leftActive) {
      return 1;
    }

    return 0;
  }

  private updatePointerSteering(clientX: number) {
    if (!this.canvas) {
      return;
    }
    const rect = this.canvas.getBoundingClientRect();
    const relative = (clientX - rect.left) / rect.width;
    this.pointerSteering = Math.min(1, Math.max(-1, (relative - 0.5) * 2));
  }

  private handleMouseDown = (event: MouseEvent) => {
    if (event.button !== 0) {
      return;
    }
    event.preventDefault();
    this.accelerating = true;
    this.pointerActive = true;
    this.updatePointerSteering(event.clientX);
    this.emit();
  };

  private handleMouseMove = (event: MouseEvent) => {
    if (!this.pointerActive) {
      return;
    }
    event.preventDefault();
    this.updatePointerSteering(event.clientX);
    this.emit();
  };

  private handleMouseUp = (event: MouseEvent) => {
    if (event.button !== 0) {
      return;
    }
    event.preventDefault();
    this.accelerating = false;
    this.pointerActive = false;
    this.pointerSteering = 0;
    this.emit();
  };

  private handleMouseLeave = (event: MouseEvent) => {
    if (!this.pointerActive) {
      return;
    }
    event.preventDefault();
    this.accelerating = false;
    this.pointerActive = false;
    this.pointerSteering = 0;
    this.emit();
  };

  private handleTouchStart = (event: TouchEvent) => {
    event.preventDefault();
    const touch = event.touches[0];
    if (!touch) {
      return;
    }
    this.accelerating = true;
    this.pointerActive = true;
    this.updatePointerSteering(touch.clientX);
    this.emit();
  };

  private handleTouchMove = (event: TouchEvent) => {
    if (!this.pointerActive) {
      return;
    }
    event.preventDefault();
    const touch = event.touches[0];
    if (!touch) {
      return;
    }
    this.updatePointerSteering(touch.clientX);
    this.emit();
  };

  private handleTouchEnd = (event: TouchEvent) => {
    event.preventDefault();
    this.accelerating = false;
    this.pointerActive = false;
    this.pointerSteering = 0;
    this.emit();
  };

  private handleKeyDown = (event: KeyboardEvent) => {
    switch (event.code) {
      case "Space":
      case "Enter":
      case "ArrowUp":
      case "KeyW":
        event.preventDefault();
        if (!this.accelerating) {
          this.accelerating = true;
          this.emit();
        }
        break;
      case "ArrowLeft":
      case "KeyA":
        event.preventDefault();
        this.leftActive = true;
        this.emit();
        break;
      case "ArrowRight":
      case "KeyD":
        event.preventDefault();
        this.rightActive = true;
        this.emit();
        break;
      default:
        break;
    }
  };

  private handleKeyUp = (event: KeyboardEvent) => {
    switch (event.code) {
      case "Space":
      case "Enter":
      case "ArrowUp":
      case "KeyW":
        event.preventDefault();
        if (this.accelerating) {
          this.accelerating = false;
          this.emit();
        }
        break;
      case "ArrowLeft":
      case "KeyA":
        event.preventDefault();
        if (this.leftActive) {
          this.leftActive = false;
          this.emit();
        }
        break;
      case "ArrowRight":
      case "KeyD":
        event.preventDefault();
        if (this.rightActive) {
          this.rightActive = false;
          this.emit();
        }
        break;
      default:
        break;
    }
  };
}
