import { Color3, Mesh, MeshBuilder, Scene, StandardMaterial } from "@babylonjs/core";
import type { PlayerSnapshot } from "../store/useRoom";

const localColor = new Color3(0.4, 0.4, 0.45); // Cinza para carro local
const ghostColor = new Color3(0.25, 0.25, 0.3); // Cinza mais escuro para fantasmas

export class CarController {
  private readonly cars = new Map<string, Mesh>();
  private localId?: string;

  constructor(private readonly scene: Scene) {}

  setLocalPlayer(id: string) {
    this.localId = id;
    this.cars.forEach((mesh, meshId) => {
      const material = mesh.material as StandardMaterial | null;
      if (!material) {
        return;
      }
      material.diffuseColor = meshId === id ? localColor : ghostColor;
      material.alpha = meshId === id ? 1 : 0.5;
    });
  }

  update(snapshot: PlayerSnapshot) {
    const mesh = this.getOrCreate(snapshot.id);
    mesh.position.x = snapshot.x;
    mesh.position.y = snapshot.y; // Usar diretamente a posição Y calculada pela física
    mesh.position.z = snapshot.z;
    mesh.rotation.y = snapshot.yaw;

    // Aplicar inclinações da pista ao carro para que siga a curvatura
    if (snapshot.pitch !== undefined) {
      mesh.rotation.x = snapshot.pitch; // Inclinação para frente/trás
    }
    if (snapshot.roll !== undefined) {
      mesh.rotation.z = snapshot.roll; // Inclinação lateral (banking)
    }

    // Aplicar material aos filhos do carro (se for um grupo)
    if (mesh.getChildren) {
      mesh.getChildren().forEach(child => {
        const childMesh = child as Mesh;
        if (childMesh.material && (childMesh.name.includes('chassis') ||
            childMesh.name.includes('hood') ||
            childMesh.name.includes('roof') ||
            childMesh.name.includes('spoiler'))) {
          const material = childMesh.material as StandardMaterial;
          if (material) {
            material.diffuseColor = snapshot.id === this.localId ? localColor : ghostColor;
            material.alpha = snapshot.id === this.localId ? 1 : 0.5;
          }
        }
      });
    } else {
      // Fallback para carros antigos (caixa simples)
      const material = mesh.material as StandardMaterial | null;
      if (material) {
        material.diffuseColor = snapshot.id === this.localId ? localColor : ghostColor;
        material.alpha = snapshot.id === this.localId ? 1 : 0.5;
      }
    }
  }

  prune(activeIds: Set<string>) {
    Array.from(this.cars.keys()).forEach((id) => {
      if (!activeIds.has(id)) {
        this.cars.get(id)?.dispose(false, true);
        this.cars.delete(id);
      }
    });
  }

  forEach(callback: (mesh: Mesh, id: string) => void) {
    this.cars.forEach((mesh, id) => callback(mesh, id));
  }

  getMesh(id: string) {
    return this.cars.get(id);
  }

  dispose() {
    this.cars.forEach((mesh) => mesh.dispose(false, true));
    this.cars.clear();
  }

  private getOrCreate(id: string): Mesh {
    const existing = this.cars.get(id);
    if (existing) {
      return existing;
    }

    // Criar um carro mais realista no estilo Skyline
    const carGroup = new Mesh(`car-group-${id}`, this.scene);

    // Chassis principal (corpo do carro)
    const chassis = MeshBuilder.CreateBox(
      `car-chassis-${id}`,
      { height: 0.4, width: 1.8, depth: 4.2 },
      this.scene
    );
    chassis.position.y = 0.2;
    chassis.parent = carGroup;

    // Capô (mais baixo e alongado)
    const hood = MeshBuilder.CreateBox(
      `car-hood-${id}`,
      { height: 0.15, width: 1.6, depth: 1.4 },
      this.scene
    );
    hood.position.set(0, 0.475, 1.4);
    hood.parent = carGroup;

    // Teto (menor para parecer esportivo)
    const roof = MeshBuilder.CreateBox(
      `car-roof-${id}`,
      { height: 0.3, width: 1.4, depth: 2.0 },
      this.scene
    );
    roof.position.set(0, 0.55, -0.2);
    roof.parent = carGroup;

    // Para-brisa dianteiro
    const windshield = MeshBuilder.CreateBox(
      `car-windshield-${id}`,
      { height: 0.25, width: 1.3, depth: 0.1 },
      this.scene
    );
    windshield.position.set(0, 0.525, 0.9);
    windshield.rotation.x = -0.2; // Inclinação do para-brisa
    windshield.parent = carGroup;

    // Spoiler traseiro (característico do Skyline)
    const spoiler = MeshBuilder.CreateBox(
      `car-spoiler-${id}`,
      { height: 0.1, width: 1.6, depth: 0.3 },
      this.scene
    );
    spoiler.position.set(0, 0.7, -2.0);
    spoiler.parent = carGroup;

    // Rodas
    const wheelPositions = [
      { x: 0.8, z: 1.3 },   // Dianteira direita
      { x: -0.8, z: 1.3 },  // Dianteira esquerda
      { x: 0.8, z: -1.3 },  // Traseira direita
      { x: -0.8, z: -1.3 }  // Traseira esquerda
    ];

    wheelPositions.forEach((pos, index) => {
      const wheel = MeshBuilder.CreateCylinder(
        `car-wheel-${id}-${index}`,
        { height: 0.3, diameter: 0.8 },
        this.scene
      );
      wheel.position.set(pos.x, 0.1, pos.z);
      wheel.rotation.z = Math.PI / 2;
      wheel.parent = carGroup;

      // Material das rodas (mais escuro)
      const wheelMaterial = new StandardMaterial(`wheel-material-${id}-${index}`, this.scene);
      wheelMaterial.diffuseColor = new Color3(0.1, 0.1, 0.1);
      wheelMaterial.specularColor = new Color3(0.3, 0.3, 0.3);
      wheel.material = wheelMaterial;
    });

    carGroup.checkCollisions = false;
    carGroup.isPickable = false;

    // Material principal do carro
    const carMaterial = new StandardMaterial(`car-material-${id}`, this.scene);
    carMaterial.diffuseColor = id === this.localId ? localColor : ghostColor;
    carMaterial.specularColor = new Color3(0.4, 0.4, 0.4);
    carMaterial.alpha = id === this.localId ? 1 : 0.5;

    // Aplicar material aos componentes principais
    chassis.material = carMaterial;
    hood.material = carMaterial;
    roof.material = carMaterial;
    spoiler.material = carMaterial;

    // Criar faixas VV nas laterais do carro
    this.createSideStripes(carGroup, id);

    // Material do para-brisa (mais transparente)
    const glassMaterial = new StandardMaterial(`glass-material-${id}`, this.scene);
    glassMaterial.diffuseColor = new Color3(0.8, 0.9, 1.0);
    glassMaterial.specularColor = new Color3(0.9, 0.9, 0.9);
    glassMaterial.alpha = 0.3;
    windshield.material = glassMaterial;

    this.cars.set(id, carGroup);
    return carGroup;
  }

  private createSideStripes(carGroup: Mesh, id: string) {
    // Material das faixas (cor contrastante)
    const stripeMaterial = new StandardMaterial(`stripe-material-${id}`, this.scene);
    stripeMaterial.diffuseColor = new Color3(0.1, 0.1, 0.15); // Cinza mais escuro para contraste
    stripeMaterial.specularColor = new Color3(0.2, 0.2, 0.2);

    // Criar faixas VV em ambos os lados
    ['left', 'right'].forEach((side, sideIndex) => {
      const sideMultiplier = side === 'left' ? -1 : 1;

      // Duas faixas VV por lado
      for (let stripeIndex = 0; stripeIndex < 2; stripeIndex++) {
        // Faixa superior
        const upperStripe = MeshBuilder.CreateBox(
          `stripe_${side}_upper_${stripeIndex}_${id}`,
          { width: 0.08, height: 0.15, depth: 1.8 }, // Fina, mais alta, comprida
          this.scene
        );

        // Faixa inferior
        const lowerStripe = MeshBuilder.CreateBox(
          `stripe_${side}_lower_${stripeIndex}_${id}`,
          { width: 0.08, height: 0.15, depth: 1.2 }, // Fina, mais alta, menos comprida
          this.scene
        );

        // Posicionamento das faixas para formar VV
        const baseX = sideMultiplier * 0.85; // Posição na lateral do carro
        const offsetZ = stripeIndex * 0.4 - 0.2; // Espaçamento entre as duas faixas

        // Faixa superior (vai da frente até o meio)
        upperStripe.position.set(baseX, 0.1, 0.4 + offsetZ);
        upperStripe.rotation.set(0, 0, sideMultiplier * Math.PI / 12); // Inclinação para formar V

        // Faixa inferior (vai do meio até trás)
        lowerStripe.position.set(baseX, -0.1, -0.6 + offsetZ);
        lowerStripe.rotation.set(0, 0, sideMultiplier * -Math.PI / 12); // Inclinação oposta para formar V

        // Aplicar material
        upperStripe.material = stripeMaterial;
        lowerStripe.material = stripeMaterial;

        // Anexar ao grupo do carro
        upperStripe.parent = carGroup;
        lowerStripe.parent = carGroup;
      }
    });
  }
}