import { Vector3 } from "@babylonjs/core";
import type { TrackGenerator, TrackSample } from "./TrackGenerator";

export interface PlayerInputState {
  accelerate: boolean;
  steering: number;
}

interface LocalPlayerState {
  x: number;
  y: number;
  z: number;
  yaw: number; // Direção do carro
  velocity: number; // Velocidade constante

  // Sistema simplificado
  turningRight: boolean; // Se está virando para a direita
  turnStrength: number; // Intensidade da curva (0-1)

  // Sistema de inércia angular para suavidade
  angularVelocity: number; // Velocidade angular atual do carro
  targetAngularVelocity: number; // Velocidade angular desejada

  // Sistema de deriva visual suave
  visualDriftAngle: number; // Ângulo visual atual de deriva
  targetDriftAngle: number; // Ângulo visual alvo de deriva

  // Estado visual e físico
  pitch: number;
  roll: number;
  distance: number;
  gameOver: boolean;
  crashed: boolean;
  lastSyncDistance: number;
}

const DEFAULT_INPUT: PlayerInputState = { accelerate: false, steering: 0 };

export class LocalPhysics {
  private state: LocalPlayerState;
  private lastUpdate: number;
  private input: PlayerInputState;
  private track?: TrackGenerator;

  constructor(track?: TrackGenerator) {
    this.track = track;
    this.state = this.createInitialState();
    this.lastUpdate = performance.now();
    this.input = { ...DEFAULT_INPUT };
  }

  setTrack(track: TrackGenerator) {
    this.track = track;
  }

  setInput(input: PlayerInputState) {
    this.input = {
      accelerate: input.accelerate,
      steering: Math.max(-1, Math.min(1, input.steering))
    };
  }

  update() {
    const now = performance.now();
    let deltaTime = (now - this.lastUpdate) / 1000;
    this.lastUpdate = now;

    if (deltaTime <= 0 || this.state.gameOver) {
      return this.getPublicState();
    }

    // Limitar deltaTime para evitar picos que causam tremor
    deltaTime = Math.min(deltaTime, 1/30); // Máximo de 33ms por frame

    // VALIDAÇÃO INICIAL: garantir que Y nunca seja inválido
    if (!isFinite(this.state.y) || isNaN(this.state.y)) {
      this.state.y = 1.0; // Altura de segurança
    }

    const config = {
      constantSpeed: 18, // Velocidade média constante
      driftSpeed: 15, // Velocidade muito levemente reduzida quando driftando
      maxTurnRate: Math.PI / 8, // Taxa máxima ultra reduzida (22.5 graus por segundo - super suave)
      turnAcceleration: 0.8, // Velocidade ultra suave para ENTRAR na curva
      turnDeceleration: 0.03, // Velocidade extremamente lenta para SAIR da curva
      angularAcceleration: 0.6, // Aceleração angular ultra suave
      angularDeceleration: 0.15, // Desaceleração angular extremamente suave

      // Configurações para deriva visual suave
      maxDriftAngle: Math.PI / 6, // Máximo 30 graus de deriva visual
      driftAcceleration: 1.0, // Velocidade de entrada na deriva visual
      driftDeceleration: 0.4, // Velocidade ultra suave de saída da deriva visual

      rollResponse: 1.5, // Muito reduzido para eliminar tremor
      pitchResponse: 2.0 // Reduzido para eliminar tremor
    };

    const CAR_HALF_WIDTH = 0.8;

    // 1. Sistema de controle simples: clique = vira direita
    const isClicking = this.input.accelerate; // Usar accelerate como clique único

    if (isClicking) {
      // Clicando = vira para a direita de forma progressiva + velocidade levemente reduzida
      this.state.turningRight = true;
      this.state.turnStrength = Math.min(1.0, this.state.turnStrength + config.turnAcceleration * deltaTime);
      this.state.velocity = config.driftSpeed; // Velocidade levemente reduzida ao driftar

      // Definir velocidade angular alvo de forma mais progressiva (curva suave)
      const progressiveTurnRate = config.maxTurnRate * Math.pow(this.state.turnStrength, 1.5); // Curva exponencial suave
      this.state.targetAngularVelocity = progressiveTurnRate;

      // Definir ângulo de deriva visual alvo baseado na intensidade da curva
      this.state.targetDriftAngle = config.maxDriftAngle * this.state.turnStrength;
    } else {
      // Não clicando = para de virar MUITO LENTAMENTE + velocidade normal
      this.state.turningRight = false;
      this.state.turnStrength = Math.max(0.0, this.state.turnStrength - config.turnDeceleration * deltaTime);
      this.state.velocity = config.constantSpeed; // Velocidade normal

      // Velocidade angular alvo = 0 quando não clicando (mudança ultra gradual)
      this.state.targetAngularVelocity = 0;

      // Deriva visual alvo = 0 quando não clicando (retorno ultra suave)
      this.state.targetDriftAngle = 0;
    }

    // 2. Sistema de inércia angular extremamente suave para transição ultra natural
    const angularDiff = this.state.targetAngularVelocity - this.state.angularVelocity;

    if (Math.abs(angularDiff) > 0.001) {
      // Usar interpolação ultra suave com limitação extrema
      const changeRate = isClicking ? config.angularAcceleration : config.angularDeceleration;
      const maxChange = changeRate * deltaTime;

      // Aplicar mudança extremamente limitada (apenas 20% da diferença por frame)
      const smoothingFactor = isClicking ? 0.3 : 0.1; // Ainda mais suave na saída
      const actualChange = Math.sign(angularDiff) * Math.min(Math.abs(angularDiff) * smoothingFactor, maxChange);
      this.state.angularVelocity += actualChange;

      // Limitar velocidade angular máxima para evitar qualquer mudança brusca
      this.state.angularVelocity = Math.max(-config.maxTurnRate, Math.min(config.maxTurnRate, this.state.angularVelocity));

      // Aplicar damping adicional para suavidade extrema
      this.state.angularVelocity *= 0.98; // Damping muito leve
    }

    // 3. Sistema de deriva visual suave
    const driftDiff = this.state.targetDriftAngle - this.state.visualDriftAngle;

    if (Math.abs(driftDiff) > 0.001) {
      // Usar interpolação ultra suave para deriva visual
      const driftChangeRate = isClicking ? config.driftAcceleration : config.driftDeceleration;
      const maxDriftChange = driftChangeRate * deltaTime;

      // Aplicar mudança extremamente suave (apenas 15% da diferença por frame)
      const driftSmoothingFactor = isClicking ? 0.2 : 0.08; // Ainda mais suave na saída
      const actualDriftChange = Math.sign(driftDiff) * Math.min(Math.abs(driftDiff) * driftSmoothingFactor, maxDriftChange);
      this.state.visualDriftAngle += actualDriftChange;

      // Aplicar damping para deriva visual ultra suave
      this.state.visualDriftAngle *= 0.99;
    }

    // 4. Aplicar rotação baseada na velocidade angular atual (suave)
    if (Math.abs(this.state.angularVelocity) > 0.001) {
      this.state.yaw += this.state.angularVelocity * deltaTime;
    }

    this.state.yaw = this.normalizeAngle(this.state.yaw);

    // 4. Movimento direto baseado na direção atual
    const direction = new Vector3(
      Math.sin(this.state.yaw),
      0,
      Math.cos(this.state.yaw)
    );

    const travel = this.state.velocity * deltaTime;
    this.state.x += direction.x * travel;
    this.state.z += direction.z * travel;
    this.state.distance += travel;

    // 5. Atualizar posição na pista
    this.updateTrackPosition(deltaTime, CAR_HALF_WIDTH, config);

    return this.getPublicState();
  }

  // Método melhorado para atualizar posição na pista
  private updateTrackPosition(deltaTime: number, carHalfWidth: number, config: any) {
    // Sync track mais frequente para evitar teleporte
    if (this.track && this.state.distance - this.state.lastSyncDistance > 5) {
      this.track.syncToDistance(this.state.distance);
      this.state.lastSyncDistance = this.state.distance;
    }

    // Usar distance para obter a altura correta da pista
    const frame = this.track?.getSampleAtDistance(this.state.distance);

    if (frame && frame.position && typeof frame.position.y === 'number') {
      // SISTEMA ANTI-MERGULHO REFORÇADO: SEMPRE ACIMA DA PISTA
      const ALTURA_CARRO = 0.8; // Altura fixa do carro aumentada para segurança
      const requiredY = frame.position.y + ALTURA_CARRO;

      // FORÇAR posição acima da pista SEMPRE - sem exceções
      if (this.state.y <= requiredY) {
        this.state.y = requiredY + 0.1; // Posicionamento IMEDIATO com margem extra
      } else {
        // Só interpolar quando está bem ACIMA (descida muito suave)
        const diff = this.state.y - requiredY;
        if (diff > 0.3) {
          this.state.y -= Math.min(diff * 1.5 * deltaTime, diff * 0.5);
        } else if (diff > 0.1) {
          this.state.y = requiredY + 0.1; // Snap para posição segura
        }
      }

      // Verificar colisões apenas com a posição atual, sem saltos
      let carPosition = new Vector3(this.state.x, this.state.y, this.state.z);
      if (!this.track!.checkBounds(carPosition, carHalfWidth)) {
        this.triggerCrash();
      }

      // Atualizar pitch e roll da pista suavemente
      const rightY = Math.max(-1, Math.min(1, frame.right.y));
      const trackRoll = Math.asin(rightY);
      this.state.roll += (trackRoll - this.state.roll) * config.rollResponse * deltaTime;

      const forwardXZ = Math.hypot(frame.forward.x, frame.forward.z);
      const trackPitch = forwardXZ < 1e-4 ? 0 : -Math.atan2(frame.forward.y, forwardXZ); // Inverter sinal para alinhar com subida

      // Limitar pitch máximo para evitar inclinações extremas
      const maxPitch = Math.PI / 6; // 30 graus máximo
      const limitedTrackPitch = Math.max(-maxPitch, Math.min(maxPitch, trackPitch));

      this.state.pitch += (limitedTrackPitch - this.state.pitch) * config.pitchResponse * deltaTime;
    }

    // VERIFICAÇÃO FINAL ANTI-MERGULHO DUPLA
    if (this.track) {
      const finalFrame = this.track.getSampleAtDistance(this.state.distance);
      if (finalFrame) {
        const MINIMA_ALTURA_ABSOLUTA = finalFrame.position.y + 0.8; // Altura mínima aumentada
        if (this.state.y < MINIMA_ALTURA_ABSOLUTA) {
          this.state.y = MINIMA_ALTURA_ABSOLUTA + 0.2; // FORÇAR posição segura com margem
        }
      }
    }

    // Verificação anti-queda geral mais rigorosa
    if (this.state.y < -2) {
      this.state.y = 3.0; // Altura de emergência mais alta
    }

    // VALIDAÇÃO FINAL: nunca permitir Y baixo demais
    if (!isFinite(this.state.y) || isNaN(this.state.y) || this.state.y < 0) {
      this.state.y = 2.0; // Altura de segurança absoluta
    }
  }

  // Sistema removido - agora usa rearSlip diretamente

  private triggerCrash() {
    this.state.crashed = true;
    this.state.gameOver = true;
    this.state.velocity = 0;
  }

  private normalizeAngle(value: number) {
    let angle = value;
    while (angle > Math.PI) angle -= Math.PI * 2;
    while (angle < -Math.PI) angle += Math.PI * 2;
    return angle;
  }

  private getPublicState() {
    // Usar deriva visual suavizada em vez de cálculo direto
    const visualYaw = this.state.yaw + this.state.visualDriftAngle;

    // Calcular intensidade baseada na deriva visual atual
    const driftIntensity = Math.abs(this.state.visualDriftAngle) / (Math.PI / 6); // Normalizar para 0-1

    return {
      x: this.state.x,
      y: this.state.y,
      z: this.state.z,
      yaw: visualYaw, // Usar yaw visual com deriva ultra suave
      pitch: this.state.pitch,
      roll: this.state.roll,
      velocity: this.state.velocity,
      pressing: this.input.accelerate, // Pressionando quando clicando
      isTurning: Math.abs(this.state.visualDriftAngle) > 0.05, // Baseado na deriva visual suave
      distance: this.state.distance,
      isDrifting: Math.abs(this.state.visualDriftAngle) > 0.15, // Considerado drift quando deriva visual alta
      slipAngle: this.state.visualDriftAngle, // Ângulo baseado na deriva visual suavizada
      gameOver: this.state.gameOver,
      crashed: this.state.crashed
    };
  }

  getState() {
    return { ...this.state };
  }

  reset() {
    this.state = this.createInitialState();
    this.lastUpdate = performance.now();
    this.input = { ...DEFAULT_INPUT };
  }

  isGameOver() {
    return this.state.gameOver;
  }

  private createInitialState(): LocalPlayerState {
    return {
      x: 0,
      y: 0.3,
      z: 0,
      yaw: 0,
      velocity: 0,

      // Sistema simplificado
      turningRight: false,
      turnStrength: 0,

      // Sistema de inércia angular
      angularVelocity: 0,
      targetAngularVelocity: 0,

      // Sistema de deriva visual suave
      visualDriftAngle: 0,
      targetDriftAngle: 0,

      // Estado visual e físico
      pitch: 0,
      roll: 0,
      distance: 0,
      gameOver: false,
      crashed: false,
      lastSyncDistance: 0
    };
  }
}
