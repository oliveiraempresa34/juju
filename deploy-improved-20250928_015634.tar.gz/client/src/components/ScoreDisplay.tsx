import React from 'react';
import { useScoreStore } from '../store/useScore';
import { useAppStore } from '../store/useApp';

export const ScoreDisplay: React.FC = () => {
  const { currentScore, bestScore } = useScoreStore();
  const { setScreen } = useAppStore();

  return (
    <div style={{
      position: 'fixed',
      top: '20px',
      left: '50%',
      transform: 'translateX(-50%)',
      zIndex: 1000,
      display: 'flex',
      gap: '30px',
      pointerEvents: 'auto',
      fontFamily: 'monospace',
      fontSize: '18px',
      fontWeight: 'bold',
    }}>
      {/* Pontuação Atual */}
      <div style={{
        background: 'rgba(0, 0, 0, 0.8)',
        color: '#00ff88',
        padding: '12px 20px',
        borderRadius: '8px',
        display: 'flex',
        alignItems: 'center',
        gap: '10px',
        border: '2px solid #00ff88',
        boxShadow: '0 0 20px rgba(0, 255, 136, 0.3)',
      }}>
        <span style={{ fontSize: '20px' }}>🎯</span>
        <div>
          <div style={{ fontSize: '12px', opacity: 0.8 }}>PONTOS</div>
          <div style={{ fontSize: '22px', lineHeight: '1' }}>{currentScore.toLocaleString()}</div>
        </div>
      </div>

      {/* Melhor Pontuação */}
      <div style={{
        background: 'rgba(0, 0, 0, 0.8)',
        color: '#ffd700',
        padding: '12px 20px',
        borderRadius: '8px',
        display: 'flex',
        alignItems: 'center',
        gap: '10px',
        border: '2px solid #ffd700',
        boxShadow: '0 0 20px rgba(255, 215, 0, 0.3)',
      }}>
        <span style={{ fontSize: '20px' }}>🏆</span>
        <div>
          <div style={{ fontSize: '12px', opacity: 0.8 }}>RECORDE</div>
          <div style={{ fontSize: '22px', lineHeight: '1' }}>{bestScore.toLocaleString()}</div>
        </div>
      </div>

      {/* Botão X para sair */}
      <button
        onClick={() => setScreen('lobby')}
        style={{
          background: '#dc3545',
          color: 'white',
          border: 'none',
          borderRadius: '8px',
          width: '56px', // Mesma altura do container de recorde
          height: '56px',
          cursor: 'pointer',
          fontSize: '24px',
          fontWeight: 'bold',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          boxShadow: '0 0 20px rgba(220, 53, 69, 0.4)',
          transition: 'all 0.2s ease',
        }}
        onMouseEnter={(e) => {
          e.currentTarget.style.background = '#c82333';
          e.currentTarget.style.transform = 'scale(1.05)';
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.background = '#dc3545';
          e.currentTarget.style.transform = 'scale(1)';
        }}
      >
        ×
      </button>
    </div>
  );
};