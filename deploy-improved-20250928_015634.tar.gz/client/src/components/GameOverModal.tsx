import React from 'react';
import { useGameStore } from '../store/useGame';
import { useRoomStore } from '../store/useRoom';

interface GameOverModalProps {
  localPhysicsRef: React.MutableRefObject<any>;
  trackRef?: React.MutableRefObject<any>;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({ localPhysicsRef, trackRef }) => {
  const { isGameOver, currentDistance, startNewGame } = useGameStore();

  const handleStartNewGame = () => {
    // Resetar física local
    if (localPhysicsRef.current) {
      localPhysicsRef.current.reset();
    }

    // Resetar pista completamente
    if (trackRef?.current) {
      trackRef.current.resetTrack();
    }

    // Resetar jogador para posição inicial
    const { localPlayerId } = useRoomStore.getState();
    if (localPlayerId) {
      useRoomStore.getState().upsertPlayer({
        id: localPlayerId,
        name: 'You',
        x: 0,
        y: 0.5,
        z: 0,
        yaw: 0,
        pressing: false,
        distance: 0,
        opacity: 1
      });
    }

    // Iniciar novo jogo
    startNewGame();
  };

  if (!isGameOver) return null;

  return (
    <div style={{
      position: 'fixed',
      top: 0,
      left: 0,
      width: '100%',
      height: '100%',
      backgroundColor: 'rgba(0, 0, 0, 0.8)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      zIndex: 1000,
      color: 'white',
      fontFamily: 'Arial, sans-serif'
    }}>
      <div style={{
        backgroundColor: '#1a1a1a',
        padding: '40px',
        borderRadius: '12px',
        border: '2px solid #ff4444',
        textAlign: 'center',
        boxShadow: '0 8px 32px rgba(255, 68, 68, 0.3)'
      }}>
        <h1 style={{
          color: '#ff4444',
          fontSize: '48px',
          margin: '0 0 20px 0',
          textShadow: '0 0 10px #ff4444'
        }}>
          GAME OVER
        </h1>

        <p style={{
          fontSize: '24px',
          margin: '20px 0',
          color: '#cccccc'
        }}>
          Você saiu da pista!
        </p>

        <p style={{
          fontSize: '18px',
          margin: '20px 0',
          color: '#ffffff'
        }}>
          Distância percorrida: <span style={{ color: '#44ff44', fontWeight: 'bold' }}>
            {Math.round(currentDistance)}m
          </span>
        </p>

        <button
          onClick={handleStartNewGame}
          style={{
            backgroundColor: '#44aa44',
            color: 'white',
            border: 'none',
            padding: '15px 30px',
            fontSize: '20px',
            borderRadius: '8px',
            cursor: 'pointer',
            marginTop: '20px',
            boxShadow: '0 4px 8px rgba(0, 0, 0, 0.3)',
            transition: 'all 0.2s'
          }}
          onMouseOver={(e) => {
            e.currentTarget.style.backgroundColor = '#55bb55';
            e.currentTarget.style.transform = 'translateY(-2px)';
          }}
          onMouseOut={(e) => {
            e.currentTarget.style.backgroundColor = '#44aa44';
            e.currentTarget.style.transform = 'translateY(0)';
          }}
        >
          NOVA PARTIDA
        </button>
      </div>
    </div>
  );
};