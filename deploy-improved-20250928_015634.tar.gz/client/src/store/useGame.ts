import { create } from 'zustand';

export type GameMode = 'demo' | 'multiplayer' | 'practice';

interface GameState {
  gameMode: GameMode;
  isConnectedToServer: boolean;
  isInGame: boolean;
  isGameOver: boolean;
  currentScore: number;
  currentDistance: number;

  // Actions
  setGameMode: (mode: GameMode) => void;
  setConnectedToServer: (connected: boolean) => void;
  setInGame: (inGame: boolean) => void;
  setGameOver: (gameOver: boolean) => void;
  updateScore: (score: number) => void;
  updateDistance: (distance: number) => void;
  resetGame: () => void;
  startNewGame: () => void;
}

export const useGameStore = create<GameState>((set) => ({
  gameMode: 'demo',
  isConnectedToServer: false,
  isInGame: false,
  isGameOver: false,
  currentScore: 0,
  currentDistance: 0,

  setGameMode: (mode) => set({ gameMode: mode }),
  setConnectedToServer: (connected) => set({ isConnectedToServer: connected }),
  setInGame: (inGame) => set({ isInGame: inGame }),
  setGameOver: (gameOver) => set({ isGameOver: gameOver }),
  updateScore: (score) => set({ currentScore: score }),
  updateDistance: (distance) => set({ currentDistance: distance }),
  resetGame: () => set({
    currentScore: 0,
    currentDistance: 0,
    isInGame: false,
    isGameOver: false,
    isConnectedToServer: false
  }),
  startNewGame: () => set({
    currentScore: 0,
    currentDistance: 0,
    isInGame: true,
    isGameOver: false
  })
}));