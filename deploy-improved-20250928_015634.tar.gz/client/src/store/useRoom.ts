import { create } from "zustand";

export interface PlayerSnapshot {
  id: string;
  name: string;
  x: number;
  y: number;
  z: number;
  yaw: number;
  pitch?: number; // Inclinação para frente/trás
  roll?: number;  // Inclinação lateral (banking)
  pressing: boolean;
  distance: number;
  opacity: number;
}

type ConnectionStatus = "idle" | "connecting" | "connected" | "error";

interface RoomState {
  status: ConnectionStatus;
  players: Record<string, PlayerSnapshot>;
  localPlayerId?: string;
  seed: number;
  error?: string;
  setStatus: (status: ConnectionStatus, error?: string) => void;
  setLocalPlayerId: (id: string) => void;
  setSeed: (seed: number) => void;
  upsertPlayer: (snapshot: PlayerSnapshot) => void;
  removePlayer: (id: string) => void;
  reset: () => void;
}

export const useRoomStore = create<RoomState>((set) => ({
  status: "idle",
  players: {},
  seed: 0,
  setStatus: (status, error) => set({ status, error }),
  setLocalPlayerId: (localPlayerId) => set({ localPlayerId }),
  setSeed: (seed) => set({ seed }),
  upsertPlayer: (snapshot) =>
    set((state) => ({
      players: { ...state.players, [snapshot.id]: snapshot }
    })),
  removePlayer: (id) =>
    set((state) => {
      const nextPlayers = { ...state.players };
      delete nextPlayers[id];
      return { players: nextPlayers };
    }),
  reset: () =>
    set({
      status: "idle",
      players: {},
      seed: 0,
      localPlayerId: undefined,
      error: undefined
    })
}));