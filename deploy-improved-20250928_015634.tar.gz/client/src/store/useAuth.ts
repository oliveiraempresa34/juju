import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface User {
  id: string;
  username: string;
  email: string;
  balance: number;
}

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;

  // Actions
  login: (credentials: { username: string; password: string }) => Promise<void>;
  register: (userData: { username: string; email: string; password: string }) => Promise<void>;
  logout: () => void;
  setError: (error: string | null) => void;
  clearError: () => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      user: null,
      isAuthenticated: false,
      isLoading: false,
      error: null,

      login: async (credentials) => {
        set({ isLoading: true, error: null });

        try {
          // Simulação de login - substituir por API real
          await new Promise(resolve => setTimeout(resolve, 1000));

          const mockUser: User = {
            id: 'user_' + Date.now(),
            username: credentials.username,
            email: credentials.username + '@example.com',
            balance: 100.0
          };

          set({
            user: mockUser,
            isAuthenticated: true,
            isLoading: false
          });
        } catch (error) {
          set({
            error: 'Login failed',
            isLoading: false
          });
        }
      },

      register: async (userData) => {
        set({ isLoading: true, error: null });

        try {
          // Simulação de registro - substituir por API real
          await new Promise(resolve => setTimeout(resolve, 1000));

          const mockUser: User = {
            id: 'user_' + Date.now(),
            username: userData.username,
            email: userData.email,
            balance: 50.0 // Saldo inicial
          };

          set({
            user: mockUser,
            isAuthenticated: true,
            isLoading: false
          });
        } catch (error) {
          set({
            error: 'Registration failed',
            isLoading: false
          });
        }
      },

      logout: () => {
        set({
          user: null,
          isAuthenticated: false,
          error: null
        });
      },

      setError: (error) => set({ error }),
      clearError: () => set({ error: null })
    }),
    {
      name: 'auth-storage',
      partialize: (state) => ({
        user: state.user,
        isAuthenticated: state.isAuthenticated
      })
    }
  )
);