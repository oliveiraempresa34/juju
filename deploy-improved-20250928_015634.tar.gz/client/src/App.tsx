import React, { useEffect } from 'react';
import { ErrorBoundary } from "./ErrorBoundary";
import { Login } from "./pages/Login";
import { Lobby } from "./pages/Lobby";
import GamePage from "./pages/Game";
import { LoadingScreen } from "./components/LoadingScreen";
import { useAppStore } from "./store/useApp";
import { useAuthStore } from "./store/useAuth";

const App = () => {
  const { currentScreen, setScreen } = useAppStore();
  const { isAuthenticated, isLoading } = useAuthStore();

  // Auto-navigate based on auth state
  useEffect(() => {
    if (isAuthenticated && currentScreen === 'login') {
      setScreen('lobby');
    } else if (!isAuthenticated && currentScreen !== 'login') {
      setScreen('login');
    }
  }, [isAuthenticated, currentScreen, setScreen]);

  if (isLoading) {
    return <LoadingScreen message="Loading..." />;
  }

  const renderScreen = () => {
    switch (currentScreen) {
      case 'login':
        return <Login />;
      case 'lobby':
        return <Lobby />;
      case 'game':
        return <GamePage />;
      default:
        return <Login />;
    }
  };

  return (
    <ErrorBoundary>
      {renderScreen()}
    </ErrorBoundary>
  );
};

export default App;