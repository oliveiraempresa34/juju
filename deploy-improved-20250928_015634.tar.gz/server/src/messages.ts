export const MESSAGE = {
  INPUT: "input",
  NAME: "name"
} as const;

export type MessageType = (typeof MESSAGE)[keyof typeof MESSAGE];

export interface InputPayload {
  pressing: boolean;
}

export interface NamePayload {
  name: string;
}