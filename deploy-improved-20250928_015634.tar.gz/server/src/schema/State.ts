import { MapSchema, Schema, type } from "@colyseus/schema";

export class Player extends Schema {
  @type("string")
  id: string = "";

  @type("string")
  name: string = "Driver";

  @type("number")
  x: number = 0;

  @type("number")
  y: number = 0;

  @type("number")
  z: number = 0;

  @type("number")
  yaw: number = 0;

  @type("boolean")
  pressing: boolean = false;

  @type("number")
  distance: number = 0;

  @type("number")
  opacity: number = 1;
}

export class DriftState extends Schema {
  @type({ map: Player })
  players: MapSchema<Player> = new MapSchema<Player>();

  @type("number")
  seed: number = Date.now();
}