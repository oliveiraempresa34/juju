import { Server } from "colyseus";
import cors from "cors";
import express from "express";
import { createServer } from "http";
import { DriftRoom } from "./rooms/DriftRoom";

const port = Number(process.env.PORT) || 2567;
const app = express();

app.use(cors());
app.get("/", (_req, res) => {
  res.send("OK");
});

const httpServer = createServer(app);
const gameServer = new Server({ server: httpServer });

gameServer.define("drift", DriftRoom);

httpServer.listen(port, () => {
  console.log(`[server] Listening on http://localhost:${port}`);
});

export { app, gameServer };