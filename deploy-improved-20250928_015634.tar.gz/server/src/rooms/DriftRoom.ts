import { Client, Room } from "colyseus";
import { MESSAGE, InputPayload, NamePayload } from "../messages";
import { DriftState, Player } from "../schema/State";

const SIMULATION_RATE = 1000 / 30;
const BASE_SPEED = 12; // units per second
const YAW_ACCELERATION = 1.5; // rad/sec when drifting
const YAW_RECOVERY = 3; // lerp factor back to zero
const TRACK_HALF_WIDTH = 6;

export class DriftRoom extends Room<DriftState> {
  onCreate(): void {
    this.setState(new DriftState());
    this.setPatchRate(1000 / 18);
    this.setSimulationInterval((deltaTime) => this.updatePlayers(deltaTime), SIMULATION_RATE);

    this.onMessage(MESSAGE.INPUT, (client, payload: InputPayload) => {
      const player = this.state.players.get(client.sessionId);
      if (!player) {
        return;
      }
      player.pressing = Boolean(payload?.pressing);
    });

    this.onMessage(MESSAGE.NAME, (client, payload: NamePayload) => {
      const player = this.state.players.get(client.sessionId);
      if (!player) {
        return;
      }
      const trimmed = payload?.name?.toString().trim();
      if (trimmed) {
        player.name = trimmed.slice(0, 16);
      }
    });
  }

  onJoin(client: Client): void {
    const player = new Player();
    player.id = client.sessionId;
    player.name = `Driver-${client.sessionId.substring(0, 4)}`;
    player.opacity = 1;
    this.state.players.set(client.sessionId, player);
    client.send("seed", { seed: this.state.seed });
  }

  onLeave(client: Client): void {
    this.state.players.delete(client.sessionId);
  }

  private updatePlayers(deltaTime: number): void {
    const dt = deltaTime / 1000;
    this.state.players.forEach((player) => {
      if (player.pressing) {
        player.yaw += YAW_ACCELERATION * dt;
      } else {
        player.yaw += (0 - player.yaw) * Math.min(1, YAW_RECOVERY * dt);
      }

      const forward = BASE_SPEED * dt;
      const yaw = player.yaw;
      player.x += Math.cos(yaw) * forward;
      player.z += Math.sin(yaw) * forward;
      player.distance += forward;

      if (Math.abs(player.z) > TRACK_HALF_WIDTH) {
        this.resetPlayer(player);
      }
    });
  }

  private resetPlayer(player: Player): void {
    player.x = 0;
    player.y = 0;
    player.z = 0;
    player.yaw = 0;
    player.distance = 0;
    player.pressing = false;
  }
}